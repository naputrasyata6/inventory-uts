<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

/**
 * Regression guard: halaman daftar tidak boleh kena N+1
 * (jumlah query per halaman harus kecil, bukan sejumlah baris).
 */
class QueryPerformanceTest extends TestCase
{
    use RefreshDatabase;

    private function seedData(): void
    {
        $admin = User::factory()->admin()->create();
        $staff = User::factory()->create();
        $supplier = Supplier::factory()->create();

        $categories = Category::factory()->count(3)->create();
        $products = $categories->flatMap(fn ($c) => Product::factory()->count(8)->create([
            'category_id' => $c->id,
        ]));

        $products->take(10)->each(function (Product $p) use ($admin, $staff, $supplier) {
            Purchase::create([
                'supplier_id' => $supplier->id,
                'user_id' => $admin->id,
                'purchase_number' => 'PRC-TEST-'.substr(uniqid(), -6),
                'total' => 1000,
                'status' => 'completed',
                'purchased_at' => now(),
            ]);

            Sale::create([
                'user_id' => $staff->id,
                'sale_number' => 'SAL-TEST-'.substr(uniqid(), -6),
                'total' => 500,
                'status' => 'completed',
                'sold_at' => now(),
            ]);
        });

        $this->actingAs($admin);
    }

    private function queryCountFor(string $url): int
    {
        DB::flushQueryLog();
        DB::enableQueryLog();

        $this->get($url)->assertOk();

        return count(DB::getQueryLog());
    }

    public function test_products_index_has_no_n_plus_one(): void
    {
        $this->seedData();
        $this->assertLessThan(15, $this->queryCountFor('/products'));
    }

    public function test_purchases_index_has_no_n_plus_one(): void
    {
        $this->seedData();
        $this->assertLessThan(15, $this->queryCountFor('/purchases'));
    }

    public function test_sales_index_has_no_n_plus_one(): void
    {
        $this->seedData();
        $this->assertLessThan(15, $this->queryCountFor('/sales'));
    }

    public function test_dashboard_has_no_n_plus_one(): void
    {
        $this->seedData();
        $this->assertLessThan(15, $this->queryCountFor('/dashboard'));
    }
}
