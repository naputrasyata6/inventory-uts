<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AuthenticationTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_redirected_from_dashboard(): void
    {
        $this->get('/dashboard')->assertRedirect('/login');
    }

    public function test_guest_redirected_from_products(): void
    {
        $this->get('/products')->assertRedirect('/login');
    }

    public function test_login_with_wrong_password_rejected(): void
    {
        User::factory()->create(['email' => 'staff@example.com', 'password' => 'password123']);

        $this->post('/login', [
            'email' => 'staff@example.com',
            'password' => 'salah',
        ])->assertSessionHasErrors('email');
    }

    public function test_login_with_valid_credentials_redirects_to_dashboard(): void
    {
        $user = User::factory()->create([
            'email' => 'staff@example.com',
            'password' => 'password123',
        ]);

        $this->post('/login', [
            'email' => 'staff@example.com',
            'password' => 'password123',
        ])->assertRedirect('/dashboard');

        $this->assertAuthenticatedAs($user);
    }

    public function test_logout_redirects_to_login_and_clears_session(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->post('/logout')->assertRedirect('/login');

        $this->assertGuest();
    }
}
