<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SearchFilterTest extends TestCase
{
    use RefreshDatabase;

    public function test_product_search_filters_by_sku_or_name(): void
    {
        $user = User::factory()->create(['role' => 'staff']);
        $this->actingAs($user);

        $category = Category::factory()->create();
        Product::factory()->create(['category_id' => $category->id, 'sku' => 'BRG-777', 'name' => 'Beras Khusus']);
        Product::factory()->create(['category_id' => $category->id, 'sku' => 'MKN-999', 'name' => 'Roti Tawar']);

        $this->get('/products?search=BRG-777')
            ->assertOk()
            ->assertSee('Beras Khusus')
            ->assertDontSee('Roti Tawar');
    }

    public function test_product_category_filter_works(): void
    {
        $user = User::factory()->create(['role' => 'staff']);
        $this->actingAs($user);

        $a = Category::factory()->create();
        $b = Category::factory()->create();

        Product::factory()->create(['category_id' => $a->id, 'name' => 'Produk Kategori A']);
        Product::factory()->create(['category_id' => $b->id, 'name' => 'Produk Kategori B']);

        $this->get("/products?category_id={$a->id}")
            ->assertOk()
            ->assertSee('Produk Kategori A')
            ->assertDontSee('Produk Kategori B');
    }

    public function test_sale_status_filter_works(): void
    {
        $user = User::factory()->create(['role' => 'staff']);
        $this->actingAs($user);

        $product = Product::factory()->create();
        $service = app(\App\Services\SaleService::class);

        $sale = $service->create([
            'user_id' => $user->id,
            'items' => [['product_id' => $product->id, 'quantity' => 1]],
        ]);

        $sale->update(['status' => \App\Models\Sale::STATUS_CANCELLED]);

        $this->get('/sales?status=cancelled')
            ->assertOk()
            ->assertSee($sale->sale_number);
    }

    public function test_low_stock_page_lists_only_low_products(): void
    {
        $user = User::factory()->create(['role' => 'staff']);
        $this->actingAs($user);

        $category = Category::factory()->create();
        Product::factory()->create(['category_id' => $category->id, 'stock' => 2, 'minimum_stock' => 5]);
        Product::factory()->create(['category_id' => $category->id, 'stock' => 50, 'minimum_stock' => 5]);

        $response = $this->get('/inventory/low-stock')->assertOk();

        $this->assertStringContainsString('Stok Rendah', $response->getContent());
    }
}
