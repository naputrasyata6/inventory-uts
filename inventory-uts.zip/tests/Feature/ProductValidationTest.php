<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ProductValidationTest extends TestCase
{
    use RefreshDatabase;

    private function actingAsStaff(): User
    {
        $user = User::factory()->create(['role' => 'staff']);
        $this->actingAs($user);

        return $user;
    }

    private function productPayload(array $overrides = []): array
    {
        return array_merge([
            'sku' => 'TEST-001',
            'name' => 'Produk Uji',
            'category_id' => Category::factory()->create()->id,
            'purchase_price' => 10000,
            'selling_price' => 13000,
            'minimum_stock' => 5,
        ], $overrides);
    }

    public function test_duplicate_sku_is_rejected(): void
    {
        $this->actingAsStaff();

        Product::factory()->create(['sku' => 'DUP-001']);

        $this->post('/products', $this->productPayload(['sku' => 'DUP-001']))
            ->assertSessionHasErrors('sku');
    }

    public function test_negative_price_is_rejected(): void
    {
        $this->actingAsStaff();

        $this->post('/products', $this->productPayload(['purchase_price' => -5]))
            ->assertSessionHasErrors('purchase_price');
    }

    public function test_invalid_category_is_rejected(): void
    {
        $this->actingAsStaff();

        $this->post('/products', $this->productPayload(['category_id' => 9999]))
            ->assertSessionHasErrors('category_id');
    }

    public function test_name_required(): void
    {
        $this->actingAsStaff();

        $this->post('/products', $this->productPayload(['name' => '']))
            ->assertSessionHasErrors('name');
    }

    public function test_valid_product_can_be_created(): void
    {
        $this->actingAsStaff();

        $this->post('/products', $this->productPayload())
            ->assertRedirect();

        $this->assertDatabaseHas('products', ['sku' => 'TEST-001']);
    }
}
