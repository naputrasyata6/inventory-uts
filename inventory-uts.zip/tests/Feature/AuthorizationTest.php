<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AuthorizationTest extends TestCase
{
    use RefreshDatabase;

    private function staffUser(): User
    {
        return User::factory()->create(['role' => 'staff']);
    }

    private function adminUser(): User
    {
        return User::factory()->admin()->create();
    }

    public function test_staff_cannot_access_user_management(): void
    {
        $this->actingAs($this->staffUser())
            ->get('/users')
            ->assertForbidden();
    }

    public function test_admin_can_access_user_management(): void
    {
        $this->actingAs($this->adminUser())
            ->get('/users')
            ->assertOk();
    }

    public function test_staff_cannot_delete_master_data(): void
    {
        $category = Category::factory()->create();
        $product = Product::factory()->create(['category_id' => $category->id]);

        $this->actingAs($this->staffUser())
            ->delete("/products/{$product->id}")
            ->assertForbidden();
    }

    public function test_admin_can_soft_delete_product(): void
    {
        $admin = $this->adminUser();
        $category = Category::factory()->create();
        $product = Product::factory()->create(['category_id' => $category->id]);

        $this->actingAs($admin)
            ->delete("/products/{$product->id}")
            ->assertRedirect(route('products.index'));

        $this->assertSoftDeleted('products', ['id' => $product->id]);
    }

    public function test_staff_cannot_cancel_transaction(): void
    {
        $staff = $this->staffUser();
        $category = Category::factory()->create();
        $product = Product::factory()->create(['category_id' => $category->id, 'stock' => 10]);
        $supplier = \App\Models\Supplier::factory()->create();

        $purchase = app(\App\Services\PurchaseService::class)->create([
            'supplier_id' => $supplier->id,
            'user_id' => $staff->id,
            'items' => [
                ['product_id' => $product->id, 'quantity' => 5, 'unit_cost' => 1000],
            ],
        ]);

        $this->actingAs($staff)
            ->post("/purchases/{$purchase->id}/cancel")
            ->assertForbidden();

        $this->assertTrue($purchase->fresh()->isCompleted());
    }
}
