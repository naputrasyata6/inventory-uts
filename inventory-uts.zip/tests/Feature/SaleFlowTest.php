<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SaleFlowTest extends TestCase
{
    use RefreshDatabase;

    private User $user;
    private Product $product;

    protected function setUp(): void
    {
        parent::setUp();

        $this->user = User::factory()->create(['role' => 'staff']);
        $this->actingAs($this->user);

        $this->product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'stock' => 10,
        ]);
    }

    private function salePayload(array $overrides = []): array
    {
        return array_merge([
            'items' => [
                ['product_id' => $this->product->id, 'quantity' => 3],
            ],
        ], $overrides);
    }

    public function test_sale_decrements_stock_and_uses_database_price(): void
    {
        $this->post('/sales', $this->salePayload())->assertRedirect();

        $this->assertSame(7, $this->product->fresh()->stock);

        $sale = \App\Models\Sale::first();
        $expected = $this->product->selling_price * 3;

        $this->assertSame(number_format($expected, 2, '.', ''), number_format($sale->total, 2, '.', ''));
        $this->assertDatabaseHas('sale_items', [
            'product_id' => $this->product->id,
            'quantity' => 3,
            'unit_price' => $this->product->selling_price,
        ]);
    }

    public function test_insufficient_stock_is_rejected_without_changes(): void
    {
        $payload = $this->salePayload(['items' => [
            ['product_id' => $this->product->id, 'quantity' => 15],
        ]]);

        $this->post('/sales', $payload)->assertSessionHasErrors('items');

        $this->assertSame(10, $this->product->fresh()->stock);
        $this->assertDatabaseCount('sales', 0);
        $this->assertDatabaseCount('sale_items', 0);
    }

    public function test_atomicity_rollback_when_one_item_fails(): void
    {
        $second = Product::factory()->create([
            'category_id' => $this->product->category_id,
            'stock' => 2,
        ]);

        $payload = $this->salePayload(['items' => [
            ['product_id' => $this->product->id, 'quantity' => 2],
            ['product_id' => $second->id, 'quantity' => 99],
        ]]);

        $this->post('/sales', $payload)->assertSessionHasErrors('items');

        $this->assertSame(10, $this->product->fresh()->stock);
        $this->assertSame(2, $second->fresh()->stock);
        $this->assertDatabaseCount('sales', 0);
        $this->assertDatabaseCount('sale_items', 0);
    }

    public function test_sale_requires_positive_quantity(): void
    {
        $payload = $this->salePayload(['items' => [
            ['product_id' => $this->product->id, 'quantity' => 0],
        ]]);

        $this->post('/sales', $payload)->assertSessionHasErrors('items.0.quantity');
    }

    public function test_cancel_sale_restores_stock(): void
    {
        $this->post('/sales', $this->salePayload())->assertRedirect();

        $sale = \App\Models\Sale::first();
        $this->assertSame(7, $this->product->fresh()->stock);

        $this->actingAs(User::factory()->admin()->create());
        $this->post("/sales/{$sale->id}/cancel")->assertRedirect();

        $this->assertSame(10, $this->product->fresh()->stock);
        $this->assertSame('cancelled', $sale->fresh()->status);
    }
}
