<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PurchaseFlowTest extends TestCase
{
    use RefreshDatabase;

    private User $user;
    private Supplier $supplier;
    private Product $product;

    protected function setUp(): void
    {
        parent::setUp();

        $this->user = User::factory()->create(['role' => 'staff']);
        $this->actingAs($this->user);

        $this->supplier = Supplier::factory()->create();
        $category = Category::factory()->create();
        $this->product = Product::factory()->create([
            'category_id' => $category->id,
            'stock' => 0,
        ]);
    }

    private function purchasePayload(array $overrides = []): array
    {
        return array_merge([
            'supplier_id' => $this->supplier->id,
            'items' => [
                ['product_id' => $this->product->id, 'quantity' => 5, 'unit_cost' => 10000],
            ],
        ], $overrides);
    }

    public function test_purchase_adds_stock_and_records_transaction(): void
    {
        $this->post('/purchases', $this->purchasePayload())->assertRedirect();

        $this->assertSame(5, $this->product->fresh()->stock);

        $this->assertDatabaseHas('purchases', [
            'supplier_id' => $this->supplier->id,
            'status' => 'completed',
        ]);

        $this->assertDatabaseHas('purchase_items', [
            'product_id' => $this->product->id,
            'quantity' => 5,
        ]);
    }

    public function test_purchase_total_is_calculated_on_server(): void
    {
        $this->post('/purchases', $this->purchasePayload())->assertRedirect();

        $purchase = \App\Models\Purchase::first();

        $this->assertSame('50000.00', (string) $purchase->total);
    }

    public function test_purchase_requires_at_least_one_item(): void
    {
        $this->post('/purchases', $this->purchasePayload(['items' => []]))
            ->assertSessionHasErrors('items');
    }

    public function test_purchase_rejects_negative_quantity(): void
    {
        $payload = $this->purchasePayload(['items' => [
            ['product_id' => $this->product->id, 'quantity' => -1, 'unit_cost' => 10000],
        ]]);

        $this->post('/purchases', $payload)->assertSessionHasErrors('items.0.quantity');
    }

    public function test_cancel_purchase_restores_stock(): void
    {
        $this->post('/purchases', $this->purchasePayload())->assertRedirect();

        $purchase = \App\Models\Purchase::first();
        $this->assertSame(5, $this->product->fresh()->stock);

        $this->actingAs(User::factory()->admin()->create());
        $this->post("/purchases/{$purchase->id}/cancel")->assertRedirect();

        $this->assertSame(0, $this->product->fresh()->stock);
        $this->assertSame('cancelled', $purchase->fresh()->status);
    }

    public function test_cancel_purchase_blocked_when_stock_has_moved_on(): void
    {
        $this->post('/purchases', $this->purchasePayload())->assertRedirect();

        // Jual sebagian dari stok hasil pembelian.
        $this->post('/sales', [
            'items' => [
                ['product_id' => $this->product->id, 'quantity' => 3],
            ],
        ])->assertRedirect();

        $purchase = \App\Models\Purchase::first();
        $this->assertSame(2, $this->product->fresh()->stock);

        $this->actingAs(User::factory()->admin()->create());
        $this->post("/purchases/{$purchase->id}/cancel")->assertSessionHasErrors('status');

        $this->assertSame('completed', $purchase->fresh()->status);
        $this->assertSame(2, $this->product->fresh()->stock);
    }

    public function test_cancel_of_already_cancelled_is_rejected(): void
    {
        $this->post('/purchases', $this->purchasePayload())->assertRedirect();
        $purchase = \App\Models\Purchase::first();

        $admin = User::factory()->admin()->create();
        $this->actingAs($admin);
        $this->post("/purchases/{$purchase->id}/cancel")->assertRedirect();
        $this->post("/purchases/{$purchase->id}/cancel")->assertSessionHasErrors('status');
    }
}
