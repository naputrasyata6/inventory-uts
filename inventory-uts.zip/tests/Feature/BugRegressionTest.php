<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\User;
use App\Services\PurchaseService;
use App\Services\SaleService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BugRegressionTest extends TestCase
{
    use RefreshDatabase;

    public function test_generated_urls_follow_request_scheme(): void
    {
        $this->assertStringStartsWith('http://', route('login'));
    }

    public function test_users_page_renders_when_more_than_one_user_exists(): void
    {
        $admin = User::factory()->admin()->create();
        User::factory()->count(3)->create();

        $this->actingAs($admin)->get('/users')->assertOk();
    }

    public function test_admin_cannot_delete_user_with_transactions(): void
    {
        $admin = User::factory()->admin()->create();
        $staff = User::factory()->create(['role' => 'staff']);
        $supplier = Supplier::factory()->create();
        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'stock' => 0,
        ]);

        app(PurchaseService::class)->create([
            'supplier_id' => $supplier->id,
            'user_id' => $staff->id,
            'items' => [['product_id' => $product->id, 'quantity' => 1, 'unit_cost' => 1000]],
        ]);

        $this->actingAs($admin)
            ->delete("/users/{$staff->id}")
            ->assertSessionHasErrors('user');

        $this->assertModelExists($staff);
    }

    public function test_transaction_numbers_use_documented_prefixes(): void
    {
        $supplier = Supplier::factory()->create();
        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'stock' => 0,
        ]);

        $purchase = app(PurchaseService::class)->create([
            'supplier_id' => $supplier->id,
            'user_id' => User::factory()->create()->id,
            'items' => [['product_id' => $product->id, 'quantity' => 1, 'unit_cost' => 1000]],
        ]);

        $this->assertStringStartsWith('PRC-', $purchase->purchase_number);

        $sale = app(SaleService::class)->create([
            'user_id' => $purchase->user_id,
            'items' => [['product_id' => $product->id, 'quantity' => 1]],
        ]);

        $this->assertStringStartsWith('SL-', $sale->sale_number);
    }

    public function test_cancel_sale_restores_stock_of_soft_deleted_product(): void
    {
        $admin = User::factory()->admin()->create();
        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'stock' => 10,
        ]);

        $sale = app(SaleService::class)->create([
            'user_id' => $admin->id,
            'items' => [['product_id' => $product->id, 'quantity' => 3]],
        ]);

        $product->delete();

        $this->actingAs($admin)
            ->post("/sales/{$sale->id}/cancel")
            ->assertRedirect();

        $this->assertSame(10, Product::withTrashed()->find($product->id)->stock);
    }
}
