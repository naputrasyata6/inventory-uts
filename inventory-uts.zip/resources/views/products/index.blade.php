@extends('layouts.app')

@section('title', 'Produk')

@section('content')
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Kelola daftar produk, harga, dan stok.</p>
        <a href="{{ route('products.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Tambah Produk
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body py-3">
            <form method="GET" action="{{ route('products.index') }}" class="row g-2 align-items-end">
                <div class="col-12 col-md-5">
                    <label class="form-label small mb-1">Cari</label>
                    <input type="text" name="search" class="form-control" placeholder="SKU atau nama produk" value="{{ $search }}">
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label small mb-1">Kategori</label>
                    <select name="category_id" class="form-select">
                        <option value="">Semua kategori</option>
                        @foreach ($categories as $category)
                            <option value="{{ $category->id }}" @selected((string) $categoryId === (string) $category->id)>{{ $category->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-12 col-md-3 d-flex gap-2">
                    <button class="btn btn-primary flex-grow-1" type="submit"><i class="bi bi-search me-1"></i>Terapkan</button>
                    <a href="{{ route('products.index') }}" class="btn btn-outline-secondary" title="Reset filter"><i class="bi bi-arrow-counterclockwise"></i></a>
                </div>
            </form>
        </div>
    </div>

    {{-- DESKTOP: Table layout --}}
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Kategori</th>
                        <th class="text-end">Harga Beli</th>
                        <th class="text-end">Harga Jual</th>
                        <th class="text-center">Stok</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($products as $product)
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <span class="arta-thumb">{{ strtoupper(substr($product->name, 0, 1)) }}</span>
                                    <div>
                                        <a href="{{ route('products.show', $product) }}" class="fw-semibold text-decoration-none">{{ $product->name }}</a>
                                        <div class="small text-soft">{{ $product->sku }}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-soft">{{ $product->category?->name }}</td>
                            <td class="text-end">{{ App\Support\Rupiah::format($product->purchase_price) }}</td>
                            <td class="text-end fw-semibold">{{ App\Support\Rupiah::format($product->selling_price) }}</td>
                            <td class="text-center">
                                <span class="badge badge-status {{ $product->is_low_stock ? 'cancelled' : 'completed' }}">
                                    {{ $product->stock }}
                                </span>
                                <span class="d-block small text-soft mt-1">min {{ $product->minimum_stock }}</span>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="{{ route('products.show', $product) }}" class="btn btn-outline-secondary" title="Detail"><i class="bi bi-eye"></i></a>
                                    <a href="{{ route('products.edit', $product) }}" class="btn btn-outline-secondary" title="Ubah"><i class="bi bi-pencil"></i></a>
                                    @can('delete-master-data')
                                        <form method="POST" action="{{ route('products.destroy', $product) }}" onsubmit="return confirm('Hapus produk ini?')" class="d-inline">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-outline-danger" title="Hapus"><i class="bi bi-trash"></i></button>
                                        </form>
                                    @endcan
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="6">
                            <div class="empty-state">
                                <div class="empty-icon"><i class="bi bi-box-seam"></i></div>
                                <div class="fw-semibold text-body">Belum ada produk</div>
                                <a href="{{ route('products.create') }}" class="btn btn-sm btn-primary mt-3">Tambah Produk</a>
                            </div>
                        </td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($products->hasPages())
            <div class="card-footer">{{ $products->links() }}</div>
        @endif
    </div>

    {{-- MOBILE: Card list layout --}}
    <div class="d-md-none d-flex flex-column gap-2">
        @forelse ($products as $product)
            <div class="card">
                <div class="card-body p-3">
                    <div class="d-flex align-items-start gap-3">
                        <span class="arta-thumb flex-shrink-0">{{ strtoupper(substr($product->name, 0, 1)) }}</span>
                        <div class="flex-grow-1 min-width-0">
                            <a href="{{ route('products.show', $product) }}" class="fw-semibold text-decoration-none text-truncate d-block">{{ $product->name }}</a>
                            <div class="small text-soft">{{ $product->sku }} · {{ $product->category?->name }}</div>
                        </div>
                        <span class="badge badge-status {{ $product->is_low_stock ? 'cancelled' : 'completed' }} flex-shrink-0">
                            Stok {{ $product->stock }}
                        </span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-2 pt-2 border-top">
                        <div class="small">
                            <span class="text-soft">Beli:</span> {{ App\Support\Rupiah::format($product->purchase_price) }}
                            <span class="text-soft ms-2">Jual:</span> <strong>{{ App\Support\Rupiah::format($product->selling_price) }}</strong>
                        </div>
                        <div class="btn-group btn-group-sm">
                            <a href="{{ route('products.show', $product) }}" class="btn btn-outline-secondary"><i class="bi bi-eye"></i></a>
                            <a href="{{ route('products.edit', $product) }}" class="btn btn-outline-secondary"><i class="bi bi-pencil"></i></a>
                            @can('delete-master-data')
                                <form method="POST" action="{{ route('products.destroy', $product) }}" onsubmit="return confirm('Hapus?')" class="d-inline">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            @endcan
                        </div>
                    </div>
                </div>
            </div>
        @empty
            <div class="card">
                <div class="card-body">
                    <div class="empty-state">
                        <div class="empty-icon"><i class="bi bi-box-seam"></i></div>
                        <div class="fw-semibold text-body">Belum ada produk</div>
                        <a href="{{ route('products.create') }}" class="btn btn-sm btn-primary mt-3">Tambah Produk</a>
                    </div>
                </div>
            </div>
        @endforelse

        @if ($products->hasPages())
            <div class="card"><div class="card-footer">{{ $products->links() }}</div></div>
        @endif
    </div>
@endsection
