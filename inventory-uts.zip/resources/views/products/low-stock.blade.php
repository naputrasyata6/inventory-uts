@extends('layouts.app')

@section('title', 'Stok Rendah')

@section('content')
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Produk dengan stok pada atau di bawah batas minimum.</p>
        <a href="{{ route('purchases.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Buat Pembelian
        </a>
    </div>

    {{-- DESKTOP: Table --}}
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr><th>Produk</th><th>Kategori</th><th class="text-center">Stok</th><th class="text-center">Minimum</th><th class="text-center">Selisih</th><th class="text-end">Aksi</th></tr></thead>
                <tbody>
                    @forelse ($products as $product)
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="arta-thumb">{{ strtoupper(substr($product->name, 0, 1)) }}</span>
                                    <div>
                                        <a href="{{ route('products.show', $product) }}" class="fw-semibold text-decoration-none">{{ $product->name }}</a>
                                        <div class="small text-soft">{{ $product->sku }}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-soft">{{ $product->category?->name }}</td>
                            <td class="text-center"><span class="badge badge-status cancelled">{{ $product->stock }}</span></td>
                            <td class="text-center text-soft">{{ $product->minimum_stock }}</td>
                            <td class="text-center text-danger fw-semibold">{{ $product->stock - $product->minimum_stock }}</td>
                            <td class="text-end"><a href="{{ route('purchases.create') }}" class="btn btn-sm btn-outline-primary">Beli stok</a></td>
                        </tr>
                    @empty
                        <tr><td colspan="6"><div class="empty-state"><div class="empty-icon"><i class="bi bi-check2-circle"></i></div><div class="fw-semibold">Semua stok sehat</div></div></td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- MOBILE: Card list --}}
    <div class="d-md-none d-flex flex-column gap-2">
        @forelse ($products as $product)
            <div class="card border-danger-subtle">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <div class="d-flex align-items-center gap-2">
                            <span class="arta-thumb">{{ strtoupper(substr($product->name, 0, 1)) }}</span>
                            <div>
                                <a href="{{ route('products.show', $product) }}" class="fw-semibold text-decoration-none">{{ $product->name }}</a>
                                <div class="small text-soft">{{ $product->sku }} · {{ $product->category?->name }}</div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-2 pt-2 border-top">
                        <div class="small">
                            <span class="text-danger fw-bold">Stok: {{ $product->stock }}</span>
                            <span class="text-soft ms-1">/ min {{ $product->minimum_stock }}</span>
                            <span class="text-danger ms-1">(selisih {{ $product->stock - $product->minimum_stock }})</span>
                        </div>
                        <a href="{{ route('purchases.create') }}" class="btn btn-sm btn-outline-primary">Beli</a>
                    </div>
                </div>
            </div>
        @empty
            <div class="card"><div class="card-body"><div class="empty-state"><div class="empty-icon"><i class="bi bi-check2-circle"></i></div><div class="fw-semibold">Semua stok sehat</div></div></div></div>
        @endforelse
    </div>
@endsection
