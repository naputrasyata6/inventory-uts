@extends('layouts.app')

@section('title', 'Pembelian')

@section('content')
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Riwayat stok masuk dari pemasok.</p>
        <a href="{{ route('purchases.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Buat Pembelian
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body py-3">
            <form method="GET" action="{{ route('purchases.index') }}" class="row g-2 align-items-end">
                <div class="col-12 col-md-4">
                    <label class="form-label small mb-1">Cari</label>
                    <input type="text" name="search" class="form-control" placeholder="Nomor atau pemasok" value="{{ $search }}">
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label small mb-1">Status</label>
                    <select name="status" class="form-select">
                        <option value="">Semua</option>
                        <option value="completed" @selected($status === 'completed')>Selesai</option>
                        <option value="cancelled" @selected($status === 'cancelled')>Dibatalkan</option>
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label small mb-1">Dari</label>
                    <input type="date" name="from" class="form-control" value="{{ $from }}">
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label small mb-1">Sampai</label>
                    <input type="date" name="to" class="form-control" value="{{ $to }}">
                </div>
                <div class="col-6 col-md-2 d-flex gap-2">
                    <button class="btn btn-primary flex-grow-1" type="submit"><i class="bi bi-search"></i></button>
                    <a href="{{ route('purchases.index') }}" class="btn btn-outline-secondary"><i class="bi bi-arrow-counterclockwise"></i></a>
                </div>
            </form>
        </div>
    </div>

    {{-- DESKTOP: Table --}}
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr>
                    <th>Nomor</th><th>Pemasok</th><th class="text-center">Item</th>
                    <th class="text-end">Total</th><th>Status</th><th>Tanggal</th><th class="text-end">Aksi</th>
                </tr></thead>
                <tbody>
                    @forelse ($purchases as $purchase)
                        <tr>
                            <td class="fw-semibold">{{ $purchase->purchase_number }}</td>
                            <td>{{ $purchase->supplier?->name }}</td>
                            <td class="text-center">{{ $purchase->items_count }}</td>
                            <td class="text-end fw-semibold">{{ App\Support\Rupiah::format($purchase->total) }}</td>
                            <td><span class="badge badge-status {{ $purchase->status }}">{{ $purchase->isCompleted() ? 'Selesai' : 'Dibatalkan' }}</span></td>
                            <td class="text-soft">{{ $purchase->purchased_at->format('d M Y') }}</td>
                            <td class="text-end"><a href="{{ route('purchases.show', $purchase) }}" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye me-1"></i>Detail</a></td>
                        </tr>
                    @empty
                        <tr><td colspan="7"><div class="empty-state"><div class="empty-icon"><i class="bi bi-box-arrow-down"></i></div><div class="fw-semibold">Belum ada pembelian</div><a href="{{ route('purchases.create') }}" class="btn btn-sm btn-primary mt-3">Buat Pembelian</a></div></td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($purchases->hasPages())<div class="card-footer">{{ $purchases->links() }}</div>@endif
    </div>

    {{-- MOBILE: Card list --}}
    <div class="d-md-none d-flex flex-column gap-2">
        @forelse ($purchases as $purchase)
            <a href="{{ route('purchases.show', $purchase) }}" class="card text-decoration-none">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <span class="fw-semibold small">{{ $purchase->purchase_number }}</span>
                        <span class="badge badge-status {{ $purchase->status }}">{{ $purchase->isCompleted() ? 'Selesai' : 'Dibatalkan' }}</span>
                    </div>
                    <div class="small text-soft mb-2">{{ $purchase->supplier?->name }} · {{ $purchase->purchased_at->format('d M Y') }}</div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="small">{{ $purchase->items_count }} item</span>
                        <span class="fw-bold">{{ App\Support\Rupiah::format($purchase->total) }}</span>
                    </div>
                </div>
            </a>
        @empty
            <div class="card"><div class="card-body"><div class="empty-state"><div class="empty-icon"><i class="bi bi-box-arrow-down"></i></div><div class="fw-semibold">Belum ada pembelian</div><a href="{{ route('purchases.create') }}" class="btn btn-sm btn-primary mt-3">Buat Pembelian</a></div></div></div>
        @endforelse
        @if ($purchases->hasPages())<div class="card"><div class="card-footer">{{ $purchases->links() }}</div></div>@endif
    </div>
@endsection
