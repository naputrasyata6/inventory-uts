<tr data-row>
    <td style="min-width: 220px;">
        <select class="form-select form-select-sm @error('items.'.$index.'.product_id') is-invalid @enderror" name="items[{{ $index }}][product_id]" data-product-select required>
            <option value="">Pilih produk</option>
            @foreach ($products as $product)
                <option
                    value="{{ $product->id }}"
                    data-price="{{ $product->purchase_price }}"
                    @selected(
                        ((isset($item['product_id']) && (string) $item['product_id'] === (string) $product->id) ||
                        (string) old('items.'.$index.'.product_id') === (string) $product->id)
                    )
                >{{ $product->name }} ({{ $product->sku }})</option>
            @endforeach
        </select>
        @error('items.'.$index.'.product_id')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
    </td>
    <td style="width: 120px;">
        <input type="number" min="1" name="items[{{ $index }}][quantity]" data-qty class="form-control form-control-sm @error('items.'.$index.'.quantity') is-invalid @enderror" value="{{ $item['quantity'] ?? old('items.'.$index.'.quantity') }}" required>
        @error('items.'.$index.'.quantity')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
    </td>
    <td style="width: 190px;">
        <div class="input-group input-group-sm">
            <span class="input-group-text">Rp</span>
            <input type="number" min="0" step="0.01" name="items[{{ $index }}][unit_cost]" data-unit-cost class="form-control @error('items.'.$index.'.unit_cost') is-invalid @enderror" value="{{ $item['unit_cost'] ?? old('items.'.$index.'.unit_cost') }}" required>
            @error('items.'.$index.'.unit_cost')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>
    </td>
    <td class="text-end fw-semibold text-nowrap" data-subtotal>Rp 0</td>
    <td class="text-end" style="width: 60px;">
        <button type="button" class="btn btn-sm btn-outline-danger" data-remove-row title="Hapus baris" aria-label="Hapus baris">
            <i class="bi bi-trash"></i>
        </button>
    </td>
</tr>
