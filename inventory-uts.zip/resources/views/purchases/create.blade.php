@extends('layouts.app')

@section('title', 'Buat Pembelian')

@section('content')
    <form method="POST" action="{{ route('purchases.store') }}" id="purchase-form" data-transaction-form>
        @csrf

        <div class="card mb-3">
            <div class="card-header"><i class="bi bi-truck me-2"></i>Informasi Pembelian</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-6">
                        <label for="supplier_id" class="form-label">Pemasok <span class="text-danger">*</span></label>
                        <select id="supplier_id" name="supplier_id" class="form-select @error('supplier_id') is-invalid @enderror" required>
                            <option value="">Pilih pemasok</option>
                            @foreach ($suppliers as $supplier)
                                <option value="{{ $supplier->id }}" @selected(old('supplier_id') == $supplier->id)>{{ $supplier->name }}</option>
                            @endforeach
                        </select>
                        @error('supplier_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header d-flex align-items-center justify-content-between">
                <span><i class="bi bi-list-check me-2"></i>Item Barang</span>
                <button type="button" class="btn btn-sm btn-soft-primary" data-add-row>
                    <i class="bi bi-plus-lg me-1"></i>Tambah Baris
                </button>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th style="width: 120px;">Jumlah</th>
                            <th style="width: 190px;">Harga Beli / unit</th>
                            <th class="text-end" style="width: 150px;">Subtotal</th>
                            <th style="width: 60px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        @if (old('items'))
                            @foreach (old('items') as $idx => $item)
                                @include('purchases._row', ['index' => $idx, 'item' => $item])
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div class="card-footer d-flex justify-content-end align-items-center gap-3">
                <span class="text-soft">Total Pembelian</span>
                <span class="fs-4 fw-bold" data-grand-total>Rp 0</span>
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="{{ route('purchases.index') }}" class="btn btn-outline-secondary">Batal</a>
            <button type="submit" class="btn btn-primary px-4">
                <i class="bi bi-check-lg me-1"></i>Simpan Pembelian
            </button>
        </div>

        <template>
            @include('purchases._row', ['index' => 0, 'item' => null])
        </template>
    </form>
@endsection
