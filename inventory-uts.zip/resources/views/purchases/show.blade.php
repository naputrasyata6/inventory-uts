@extends('layouts.app')

@section('title', 'Detail Pembelian')

@section('content')
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-start justify-content-between flex-wrap gap-2 mb-4">
                        <div>
                            <div class="d-flex align-items-center gap-2 mb-1">
                                <span class="badge badge-status {{ $purchase->status }}">{{ $purchase->isCompleted() ? 'Selesai' : 'Dibatalkan' }}</span>
                                <span class="fw-bold fs-5">{{ $purchase->purchase_number }}</span>
                            </div>
                            <div class="text-soft">{{ $purchase->purchased_at->format('d F Y, H:i') }}</div>
                        </div>
                        <a href="{{ route('purchases.index') }}" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Kembali</a>
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-sm-6">
                            <div class="rounded-3 p-3" style="background: var(--arta-surface-2);">
                                <div class="text-soft small">Pemasok</div>
                                <div class="fw-semibold">{{ $purchase->supplier?->name }}</div>
                                <div class="small text-soft">{{ $purchase->supplier?->phone }}</div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="rounded-3 p-3" style="background: var(--arta-surface-2);">
                                <div class="text-soft small">Dicatat oleh</div>
                                <div class="fw-semibold">{{ $purchase->user?->name }}</div>
                                <div class="small text-soft">{{ $purchase->user?->isAdmin() ? 'Administrator' : 'Staff' }}</div>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Produk</th>
                                    <th class="text-center" style="width: 90px;">Jumlah</th>
                                    <th class="text-end" style="width: 150px;">Harga/unit</th>
                                    <th class="text-end" style="width: 160px;">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($purchase->items as $item)
                                    <tr>
                                        <td>
                                            <div class="fw-semibold">{{ $item->product?->name ?? 'Produk terhapus' }}</div>
                                            <div class="small text-soft">{{ $item->product?->sku }}</div>
                                        </td>
                                        <td class="text-center">{{ $item->quantity }}</td>
                                        <td class="text-end">{{ App\Support\Rupiah::format($item->unit_cost) }}</td>
                                        <td class="text-end fw-semibold">{{ App\Support\Rupiah::format($item->subtotal) }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" class="text-end fw-semibold text-soft">Total</td>
                                    <td class="text-end fs-5 fw-bold">{{ App\Support\Rupiah::format($purchase->total) }}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">Tindakan</div>
                <div class="card-body">
                    <p class="small text-soft">
                        Pembatalan hanya dapat dilakukan jika stok barang belum berpindah (terjual kembali).
                        Saat dibatalkan, stok dikembalikan ke kondisi sebelum pembelian.
                    </p>
                    @can('cancel-transaction')
                        @if ($purchase->isCompleted())
                            <form method="POST" action="{{ route('purchases.cancel', $purchase) }}" onsubmit="return confirm('Yakin membatalkan pembelian ini? Stok akan dikembalikan.')">
                                @csrf
                                <button type="submit" class="btn btn-outline-danger w-100">
                                    <i class="bi bi-x-circle me-1"></i>Batalkan Pembelian
                                </button>
                            </form>
                        @else
                            <div class="alert alert-light border mb-0">
                                <i class="bi bi-info-circle me-2"></i>Transaksi ini sudah dibatalkan.
                            </div>
                        @endif
                    @endcan
                    @cannot('cancel-transaction')
                        <div class="alert alert-light border mb-0">
                            <i class="bi bi-shield-lock me-2"></i>Hanya administrator yang dapat membatalkan transaksi.
                        </div>
                    @endcannot
                </div>
            </div>
        </div>
    </div>
@endsection
