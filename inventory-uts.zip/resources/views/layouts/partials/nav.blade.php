{{-- Navigasi utama; dipakai di sidebar desktop maupun offcanvas mobile. --}}
<nav class="flex-grow-1 pb-2 overflow-auto">
    <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">
        <i class="bi bi-grid-1x2-fill"></i> Dashboard
    </a>

    <div class="nav-section">Data Master</div>
    <a class="nav-link {{ request()->routeIs('products.*') ? 'active' : '' }}" href="{{ route('products.index') }}">
        <i class="bi bi-box-seam"></i> Produk
    </a>
    <a class="nav-link {{ request()->routeIs('categories.*') ? 'active' : '' }}" href="{{ route('categories.index') }}">
        <i class="bi bi-tags"></i> Kategori
    </a>
    <a class="nav-link {{ request()->routeIs('suppliers.*') ? 'active' : '' }}" href="{{ route('suppliers.index') }}">
        <i class="bi bi-truck"></i> Pemasok
    </a>

    <div class="nav-section">Transaksi</div>
    <a class="nav-link {{ request()->routeIs('purchases.*') ? 'active' : '' }}" href="{{ route('purchases.index') }}">
        <i class="bi bi-box-arrow-down"></i> Pembelian
    </a>
    <a class="nav-link {{ request()->routeIs('sales.*') ? 'active' : '' }}" href="{{ route('sales.index') }}">
        <i class="bi bi-bag-check"></i> Penjualan
    </a>

    <div class="nav-section">Inventori</div>
    <a class="nav-link {{ request()->routeIs('low-stock.index') ? 'active' : '' }}" href="{{ route('low-stock.index') }}">
        <i class="bi bi-exclamation-diamond"></i> Stok Rendah
    </a>

    @if (Auth::user()->isAdmin())
        <div class="nav-section">Manajemen</div>
        <a class="nav-link {{ request()->routeIs('users.*') ? 'active' : '' }}" href="{{ route('users.index') }}">
            <i class="bi bi-people"></i> Pengguna
        </a>
    @endif
</nav>
