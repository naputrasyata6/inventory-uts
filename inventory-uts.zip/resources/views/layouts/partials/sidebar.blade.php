<aside class="arta-sidebar d-none d-lg-flex">
    <a href="{{ route('dashboard') }}" class="brand">
        <span class="brand-mark"><i class="bi bi-box-seam-fill"></i></span>
        <span>ARTA<span style="color: var(--arta-primary)">.</span></span>
    </a>

    @include('layouts.partials.nav')

    <div class="sidebar-footer">
        <div class="user-chip">
            <div class="avatar">{{ strtoupper(substr(Auth::user()->name, 0, 1)) }}</div>
            <div class="flex-grow-1 overflow-hidden">
                <div class="text-white fw-semibold text-truncate" style="font-size: .9rem">{{ Auth::user()->name }}</div>
                <div class="small">{{ Auth::user()->isAdmin() ? 'Administrator' : 'Staff' }}</div>
            </div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="btn btn-sm text-secondary-emphasis border-0 bg-transparent p-1" title="Keluar" aria-label="Keluar">
                    <i class="bi bi-box-arrow-right fs-6"></i>
                </button>
            </form>
        </div>
    </div>
</aside>

{{-- Offcanvas mobile --}}
<div class="offcanvas offcanvas-start d-lg-none" tabindex="-1" id="mobileNav" aria-labelledby="mobileNavLabel" style="background: var(--arta-sidebar); color: var(--arta-sidebar-ink); --bs-offcanvas-width: 280px;">
    <div class="offcanvas-header">
        <a href="{{ route('dashboard') }}" class="brand text-white text-decoration-none d-flex align-items-center gap-2 fw-bold">
            <span class="brand-mark"><i class="bi bi-box-seam-fill"></i></span>
            ARTA<span style="color: var(--arta-primary)">.</span>
        </a>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Tutup"></button>
    </div>
    <div class="offcanvas-body d-flex flex-column p-0">
        @include('layouts.partials.nav')
        <div class="p-3 border-top" style="border-color: rgba(255,255,255,.08) !important;">
            <div class="d-flex align-items-center gap-2">
                <div class="avatar">{{ strtoupper(substr(Auth::user()->name, 0, 1)) }}</div>
                <div class="flex-grow-1 overflow-hidden">
                    <div class="text-white fw-semibold text-truncate">{{ Auth::user()->name }}</div>
                    <div class="small">{{ Auth::user()->isAdmin() ? 'Administrator' : 'Staff' }}</div>
                </div>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="btn btn-sm text-secondary-emphasis border-0 bg-transparent p-1" aria-label="Keluar">
                        <i class="bi bi-box-arrow-right fs-6"></i>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
