<header class="arta-topbar">
    <button class="btn btn-outline-secondary d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileNav" aria-controls="mobileNav" aria-label="Buka menu">
        <i class="bi bi-list"></i>
    </button>

    <div class="me-auto">
        <h1 class="page-title mb-0">@yield('title')</h1>
        <nav aria-label="breadcrumb" class="d-none d-sm-block">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Beranda</a></li>
                <li class="breadcrumb-item active" aria-current="page">@yield('title')</li>
            </ol>
        </nav>
    </div>

    <button type="button" class="arta-icon-btn" data-arta-theme-toggle aria-label="Ganti mode terang/gelap" title="Ganti tema">
        <i class="bi bi-sun icon-sun"></i>
        <i class="bi bi-moon-stars icon-moon" style="display: none"></i>
    </button>

    <div class="dropdown">
        <button class="arta-icon-btn rounded-circle p-0 border-0" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Menu akun">
            <span class="avatar" style="width: 36px; height: 36px; font-size: .9rem;">{{ strtoupper(substr(Auth::user()->name, 0, 1)) }}</span>
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 mt-2">
            <li><span class="dropdown-item-text fw-semibold">{{ Auth::user()->name }}</span></li>
            <li><span class="dropdown-item-text small text-soft">{{ Auth::user()->isAdmin() ? 'Administrator' : 'Staff' }}</span></li>
            <li><hr class="dropdown-divider"></li>
            <li>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="dropdown-item">
                        <i class="bi bi-box-arrow-right me-2"></i>Keluar
                    </button>
                </form>
            </li>
        </ul>
    </div>
</header>
