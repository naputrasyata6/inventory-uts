@extends('layouts.app')

@section('title', 'Kategori')

@section('content')
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Kelompokkan produk agar lebih mudah dicari.</p>
        <a href="{{ route('categories.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Tambah Kategori
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body py-3">
            <form method="GET" action="{{ route('categories.index') }}" class="row g-2 align-items-end">
                <div class="col-12 col-md-8">
                    <label class="form-label small mb-1">Cari</label>
                    <input type="text" name="search" class="form-control" placeholder="Nama kategori" value="{{ $search }}">
                </div>
                <div class="col-12 col-md-4 d-flex gap-2">
                    <button class="btn btn-primary flex-grow-1" type="submit"><i class="bi bi-search me-1"></i>Terapkan</button>
                    <a href="{{ route('categories.index') }}" class="btn btn-outline-secondary"><i class="bi bi-arrow-counterclockwise"></i></a>
                </div>
            </form>
        </div>
    </div>

    {{-- DESKTOP: Table --}}
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr><th>Nama</th><th>Deskripsi</th><th class="text-center">Jumlah Produk</th><th class="text-end">Aksi</th></tr></thead>
                <tbody>
                    @forelse ($categories as $category)
                        <tr>
                            <td class="fw-semibold">{{ $category->name }}</td>
                            <td class="text-soft small">{{ Str::limit($category->description, 50) }}</td>
                            <td class="text-center">{{ $category->products_count }}</td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="{{ route('categories.edit', $category) }}" class="btn btn-outline-secondary"><i class="bi bi-pencil"></i></a>
                                    @can('delete-master-data')
                                        <form method="POST" action="{{ route('categories.destroy', $category) }}" onsubmit="return confirm('Hapus kategori ini?')" class="d-inline">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    @endcan
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="4"><div class="empty-state"><div class="empty-icon"><i class="bi bi-tags"></i></div><div class="fw-semibold">Belum ada kategori</div><a href="{{ route('categories.create') }}" class="btn btn-sm btn-primary mt-3">Tambah Kategori</a></div></td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($categories->hasPages())<div class="card-footer">{{ $categories->links() }}</div>@endif
    </div>

    {{-- MOBILE: Card list --}}
    <div class="d-md-none d-flex flex-column gap-2">
        @forelse ($categories as $category)
            <div class="card">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <span class="fw-semibold">{{ $category->name }}</span>
                        <span class="badge bg-light text-dark border">{{ $category->products_count }} produk</span>
                    </div>
                    @if($category->description)
                        <div class="small text-soft mb-2">{{ Str::limit($category->description, 60) }}</div>
                    @endif
                    <div class="d-flex gap-2 pt-2 border-top">
                        <a href="{{ route('categories.edit', $category) }}" class="btn btn-sm btn-outline-secondary flex-grow-1"><i class="bi bi-pencil me-1"></i>Ubah</a>
                        @can('delete-master-data')
                            <form method="POST" action="{{ route('categories.destroy', $category) }}" onsubmit="return confirm('Hapus?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        @endcan
                    </div>
                </div>
            </div>
        @empty
            <div class="card"><div class="card-body"><div class="empty-state"><div class="empty-icon"><i class="bi bi-tags"></i></div><div class="fw-semibold">Belum ada kategori</div><a href="{{ route('categories.create') }}" class="btn btn-sm btn-primary mt-3">Tambah Kategori</a></div></div></div>
        @endforelse
        @if ($categories->hasPages())<div class="card"><div class="card-footer">{{ $categories->links() }}</div></div>@endif
    </div>
@endsection
