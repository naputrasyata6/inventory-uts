@extends('layouts.app')

@section('title', 'Penjualan')

@section('content')
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Riwayat penjualan dan stok keluar.</p>
        <a href="{{ route('sales.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Buat Penjualan
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body py-3">
            <form method="GET" action="{{ route('sales.index') }}" class="row g-2 align-items-end">
                <div class="col-12 col-md-4">
                    <label class="form-label small mb-1">Cari</label>
                    <input type="text" name="search" class="form-control" placeholder="Nomor atau kasir" value="{{ $search }}">
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label small mb-1">Status</label>
                    <select name="status" class="form-select">
                        <option value="">Semua</option>
                        <option value="completed" @selected($status === 'completed')>Selesai</option>
                        <option value="cancelled" @selected($status === 'cancelled')>Dibatalkan</option>
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label small mb-1">Dari</label>
                    <input type="date" name="from" class="form-control" value="{{ $from }}">
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label small mb-1">Sampai</label>
                    <input type="date" name="to" class="form-control" value="{{ $to }}">
                </div>
                <div class="col-6 col-md-2 d-flex gap-2">
                    <button class="btn btn-primary flex-grow-1" type="submit"><i class="bi bi-search"></i></button>
                    <a href="{{ route('sales.index') }}" class="btn btn-outline-secondary"><i class="bi bi-arrow-counterclockwise"></i></a>
                </div>
            </form>
        </div>
    </div>

    {{-- DESKTOP: Table --}}
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr>
                    <th>Nomor</th><th>Kasir</th><th class="text-center">Item</th>
                    <th class="text-end">Total</th><th>Status</th><th>Tanggal</th><th class="text-end">Aksi</th>
                </tr></thead>
                <tbody>
                    @forelse ($sales as $sale)
                        <tr>
                            <td class="fw-semibold">{{ $sale->sale_number }}</td>
                            <td>{{ $sale->user?->name }}</td>
                            <td class="text-center">{{ $sale->items_count }}</td>
                            <td class="text-end fw-semibold">{{ App\Support\Rupiah::format($sale->total) }}</td>
                            <td><span class="badge badge-status {{ $sale->status }}">{{ $sale->isCompleted() ? 'Selesai' : 'Dibatalkan' }}</span></td>
                            <td class="text-soft">{{ $sale->sold_at->format('d M Y') }}</td>
                            <td class="text-end"><a href="{{ route('sales.show', $sale) }}" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye me-1"></i>Detail</a></td>
                        </tr>
                    @empty
                        <tr><td colspan="7"><div class="empty-state"><div class="empty-icon"><i class="bi bi-bag-check"></i></div><div class="fw-semibold">Belum ada penjualan</div><a href="{{ route('sales.create') }}" class="btn btn-sm btn-primary mt-3">Buat Penjualan</a></div></td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($sales->hasPages())<div class="card-footer">{{ $sales->links() }}</div>@endif
    </div>

    {{-- MOBILE: Card list --}}
    <div class="d-md-none d-flex flex-column gap-2">
        @forelse ($sales as $sale)
            <a href="{{ route('sales.show', $sale) }}" class="card text-decoration-none">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <span class="fw-semibold small">{{ $sale->sale_number }}</span>
                        <span class="badge badge-status {{ $sale->status }}">{{ $sale->isCompleted() ? 'Selesai' : 'Dibatalkan' }}</span>
                    </div>
                    <div class="small text-soft mb-2">{{ $sale->user?->name }} · {{ $sale->sold_at->format('d M Y') }}</div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="small">{{ $sale->items_count }} item</span>
                        <span class="fw-bold">{{ App\Support\Rupiah::format($sale->total) }}</span>
                    </div>
                </div>
            </a>
        @empty
            <div class="card"><div class="card-body"><div class="empty-state"><div class="empty-icon"><i class="bi bi-bag-check"></i></div><div class="fw-semibold">Belum ada penjualan</div><a href="{{ route('sales.create') }}" class="btn btn-sm btn-primary mt-3">Buat Penjualan</a></div></div></div>
        @endforelse
        @if ($sales->hasPages())<div class="card"><div class="card-footer">{{ $sales->links() }}</div></div>@endif
    </div>
@endsection
