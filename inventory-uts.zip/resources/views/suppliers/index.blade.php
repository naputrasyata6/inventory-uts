@extends('layouts.app')

@section('title', 'Pemasok')

@section('content')
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Daftar pemasok barang untuk transaksi pembelian.</p>
        <a href="{{ route('suppliers.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Tambah Pemasok
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body py-3">
            <form method="GET" action="{{ route('suppliers.index') }}" class="row g-2 align-items-end">
                <div class="col-12 col-md-8">
                    <label class="form-label small mb-1">Cari</label>
                    <input type="text" name="search" class="form-control" placeholder="Nama atau email pemasok" value="{{ $search }}">
                </div>
                <div class="col-12 col-md-4 d-flex gap-2">
                    <button class="btn btn-primary flex-grow-1" type="submit"><i class="bi bi-search me-1"></i>Terapkan</button>
                    <a href="{{ route('suppliers.index') }}" class="btn btn-outline-secondary"><i class="bi bi-arrow-counterclockwise"></i></a>
                </div>
            </form>
        </div>
    </div>

    {{-- DESKTOP: Table --}}
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr><th>Pemasok</th><th>Kontak</th><th>Alamat</th><th class="text-center">Pembelian</th><th class="text-end">Aksi</th></tr></thead>
                <tbody>
                    @forelse ($suppliers as $supplier)
                        <tr>
                            <td class="fw-semibold">{{ $supplier->name }}</td>
                            <td><div class="small">{{ $supplier->phone }}</div><div class="small text-soft">{{ $supplier->email }}</div></td>
                            <td class="text-soft small">{{ Str::limit($supplier->address, 40) }}</td>
                            <td class="text-center">{{ $supplier->purchases_count }}</td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="{{ route('suppliers.edit', $supplier) }}" class="btn btn-outline-secondary"><i class="bi bi-pencil"></i></a>
                                    @can('delete-master-data')
                                        <form method="POST" action="{{ route('suppliers.destroy', $supplier) }}" onsubmit="return confirm('Hapus pemasok ini?')" class="d-inline">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    @endcan
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="5"><div class="empty-state"><div class="empty-icon"><i class="bi bi-truck"></i></div><div class="fw-semibold">Belum ada pemasok</div><a href="{{ route('suppliers.create') }}" class="btn btn-sm btn-primary mt-3">Tambah Pemasok</a></div></td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($suppliers->hasPages())<div class="card-footer">{{ $suppliers->links() }}</div>@endif
    </div>

    {{-- MOBILE: Card list --}}
    <div class="d-md-none d-flex flex-column gap-2">
        @forelse ($suppliers as $supplier)
            <div class="card">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <span class="fw-semibold">{{ $supplier->name }}</span>
                        <span class="badge bg-light text-dark border">{{ $supplier->purchases_count }} pembelian</span>
                    </div>
                    <div class="small text-soft mb-1"><i class="bi bi-telephone me-1"></i>{{ $supplier->phone }}</div>
                    <div class="small text-soft mb-2"><i class="bi bi-envelope me-1"></i>{{ $supplier->email }}</div>
                    @if($supplier->address)
                        <div class="small text-soft mb-2"><i class="bi bi-geo-alt me-1"></i>{{ Str::limit($supplier->address, 50) }}</div>
                    @endif
                    <div class="d-flex gap-2 pt-2 border-top">
                        <a href="{{ route('suppliers.edit', $supplier) }}" class="btn btn-sm btn-outline-secondary flex-grow-1"><i class="bi bi-pencil me-1"></i>Ubah</a>
                        @can('delete-master-data')
                            <form method="POST" action="{{ route('suppliers.destroy', $supplier) }}" onsubmit="return confirm('Hapus?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        @endcan
                    </div>
                </div>
            </div>
        @empty
            <div class="card"><div class="card-body"><div class="empty-state"><div class="empty-icon"><i class="bi bi-truck"></i></div><div class="fw-semibold">Belum ada pemasok</div><a href="{{ route('suppliers.create') }}" class="btn btn-sm btn-primary mt-3">Tambah Pemasok</a></div></div></div>
        @endforelse
        @if ($suppliers->hasPages())<div class="card"><div class="card-footer">{{ $suppliers->links() }}</div></div>@endif
    </div>
@endsection
