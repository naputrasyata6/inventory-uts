@extends('layouts.app')

@section('title', 'Pengguna')

@section('content')
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Kelola akun dan hak akses pengguna.</p>
        <a href="{{ route('users.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-person-plus me-1"></i>Tambah Pengguna
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body py-3">
            <form method="GET" action="{{ route('users.index') }}" class="row g-2 align-items-end">
                <div class="col-12 col-md-8">
                    <label class="form-label small mb-1">Cari</label>
                    <input type="text" name="search" class="form-control" placeholder="Nama atau email" value="{{ $search }}">
                </div>
                <div class="col-12 col-md-4 d-flex gap-2">
                    <button class="btn btn-primary flex-grow-1" type="submit"><i class="bi bi-search me-1"></i>Terapkan</button>
                    <a href="{{ route('users.index') }}" class="btn btn-outline-secondary"><i class="bi bi-arrow-counterclockwise"></i></a>
                </div>
            </form>
        </div>
    </div>

    {{-- DESKTOP: Table --}}
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr><th>Nama</th><th>Email</th><th>Role</th><th>Terdaftar</th><th class="text-end">Aksi</th></tr></thead>
                <tbody>
                    @forelse ($users as $user)
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="arta-thumb">{{ strtoupper(substr($user->name, 0, 1)) }}</span>
                                    <span class="fw-semibold">{{ $user->name }}</span>
                                    @if($user->id === auth()->id())<span class="badge bg-primary-subtle text-primary small">Anda</span>@endif
                                </div>
                            </td>
                            <td class="text-soft">{{ $user->email }}</td>
                            <td><span class="badge {{ $user->isAdmin() ? 'bg-primary' : 'bg-secondary' }}">{{ $user->isAdmin() ? 'Administrator' : 'Staff' }}</span></td>
                            <td class="text-soft small">{{ $user->created_at->format('d M Y') }}</td>
                            <td class="text-end">
                                @if($user->id !== auth()->id())
                                    <div class="btn-group btn-group-sm">
                                        <form method="POST" action="{{ route('users.toggle-role', $user) }}" class="d-inline">
                                            @csrf
                                            <button type="submit" class="btn btn-outline-secondary" title="{{ $user->isAdmin() ? 'Jadikan Staff' : 'Jadikan Admin' }}">
                                                <i class="bi bi-person-gear"></i>
                                            </button>
                                        </form>
                                        <form method="POST" action="{{ route('users.destroy', $user) }}" onsubmit="return confirm('Hapus pengguna ini?')" class="d-inline">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </div>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="5"><div class="empty-state"><div class="empty-icon"><i class="bi bi-people"></i></div><div class="fw-semibold">Belum ada pengguna</div></div></td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($users->hasPages())<div class="card-footer">{{ $users->links() }}</div>@endif
    </div>

    {{-- MOBILE: Card list --}}
    <div class="d-md-none d-flex flex-column gap-2">
        @forelse ($users as $user)
            <div class="card">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <div class="d-flex align-items-center gap-2">
                            <span class="arta-thumb">{{ strtoupper(substr($user->name, 0, 1)) }}</span>
                            <div>
                                <span class="fw-semibold">{{ $user->name }}</span>
                                @if($user->id === auth()->id())<span class="badge bg-primary-subtle text-primary small ms-1">Anda</span>@endif
                            </div>
                        </div>
                        <span class="badge {{ $user->isAdmin() ? 'bg-primary' : 'bg-secondary' }}">{{ $user->isAdmin() ? 'Admin' : 'Staff' }}</span>
                    </div>
                    <div class="small text-soft mb-2">{{ $user->email }} · {{ $user->created_at->format('d M Y') }}</div>
                    @if($user->id !== auth()->id())
                        <div class="d-flex gap-2 pt-2 border-top">
                            <form method="POST" action="{{ route('users.toggle-role', $user) }}" class="flex-grow-1">
                                @csrf
                                <button type="submit" class="btn btn-sm btn-outline-secondary w-100">
                                    <i class="bi bi-person-gear me-1"></i>{{ $user->isAdmin() ? 'Jadikan Staff' : 'Jadikan Admin' }}
                                </button>
                            </form>
                            <form method="POST" action="{{ route('users.destroy', $user) }}" onsubmit="return confirm('Hapus?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                    @endif
                </div>
            </div>
        @empty
            <div class="card"><div class="card-body"><div class="empty-state"><div class="empty-icon"><i class="bi bi-people"></i></div><div class="fw-semibold">Belum ada pengguna</div></div></div></div>
        @endforelse
        @if ($users->hasPages())<div class="card"><div class="card-footer">{{ $users->links() }}</div></div>@endif
    </div>
@endsection
