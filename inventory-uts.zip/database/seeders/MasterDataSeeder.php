<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use Illuminate\Database\Seeder;

class MasterDataSeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'Sembako & Beras', 'description' => 'Bahan pokok dan beras berbagai kualitas.'],
            ['name' => 'Minuman', 'description' => 'Air mineral, susu, kopi, teh, dan minuman kemasan.'],
            ['name' => 'Makanan Ringan', 'description' => 'Roti, camilan, dan makanan instan.'],
            ['name' => 'Bumbu & Rempah', 'description' => 'Kecap, garam, sambal, dan bumbu dapur.'],
            ['name' => 'Kebutuhan Rumah Tangga', 'description' => 'Produk kebersihan dan keperluan rumah tangga.'],
            ['name' => 'Perawatan Diri', 'description' => 'Sabun, shampo, pasta gigi, dan kebutuhan pribadi.'],
        ];

        foreach ($categories as $category) {
            Category::create($category);
        }

        $suppliers = [
            [
                'name' => 'PT Sumber Berkah Pangan',
                'phone' => '0812-6001-2233',
                'email' => 'admin@sumberberkah.co.id',
                'address' => 'Jl. Soekarno-Hatta, Banda Aceh',
            ],
            [
                'name' => 'CV Niaga Mandiri Utama',
                'phone' => '0852-7011-8890',
                'email' => 'sales@niagamandiri.co.id',
                'address' => 'Jl. Darussalam, Lhokseumawe',
            ],
            [
                'name' => 'UD Rizki Pangan',
                'phone' => '0823-8812-4455',
                'email' => 'rizkipangan@gmail.com',
                'address' => 'Desa Cot Keumuneng, Aceh Utara',
            ],
            [
                'name' => 'PT Segar Sentosa',
                'phone' => '061-8001-2345',
                'email' => 'cs@segarsentosa.co.id',
                'address' => 'Jl. Gatot Subroto, Medan',
            ],
            [
                'name' => 'CV Andalan Niaga',
                'phone' => '0811-6078-1122',
                'email' => 'andalan.niaga@gmail.com',
                'address' => 'Jl. T. Hamzah Bendahara, Langsa',
            ],
        ];

        foreach ($suppliers as $supplier) {
            Supplier::create($supplier);
        }

        $products = [
            ['sku' => 'BRG-0001', 'name' => 'Beras Premium 5kg', 'category' => 'Sembako & Beras', 'purchase_price' => 58000, 'selling_price' => 62000, 'stock' => 40, 'minimum_stock' => 10],
            ['sku' => 'BRG-0002', 'name' => 'Beras Medium 5kg', 'category' => 'Sembako & Beras', 'purchase_price' => 52000, 'selling_price' => 56000, 'stock' => 35, 'minimum_stock' => 10],
            ['sku' => 'BRG-0003', 'name' => 'Gula Pasir 1kg', 'category' => 'Sembako & Beras', 'purchase_price' => 16500, 'selling_price' => 18000, 'stock' => 80, 'minimum_stock' => 20],
            ['sku' => 'BRG-0004', 'name' => 'Telur Ayam 1kg', 'category' => 'Sembako & Beras', 'purchase_price' => 24000, 'selling_price' => 26000, 'stock' => 25, 'minimum_stock' => 8],
            ['sku' => 'BRG-0005', 'name' => 'Minyak Goreng 1L', 'category' => 'Sembako & Beras', 'purchase_price' => 17500, 'selling_price' => 19000, 'stock' => 60, 'minimum_stock' => 15],
            ['sku' => 'MNM-0001', 'name' => 'Susu Kental Manis 385ml', 'category' => 'Minuman', 'purchase_price' => 10500, 'selling_price' => 12000, 'stock' => 45, 'minimum_stock' => 12],
            ['sku' => 'MNM-0002', 'name' => 'Kopi Bubuk 250g', 'category' => 'Minuman', 'purchase_price' => 28000, 'selling_price' => 32000, 'stock' => 4, 'minimum_stock' => 8],
            ['sku' => 'MNM-0003', 'name' => 'Teh Celup 25s', 'category' => 'Minuman', 'purchase_price' => 9000, 'selling_price' => 11000, 'stock' => 50, 'minimum_stock' => 15],
            ['sku' => 'MNM-0004', 'name' => 'Air Mineral 600ml (dus)', 'category' => 'Minuman', 'purchase_price' => 22000, 'selling_price' => 26000, 'stock' => 5, 'minimum_stock' => 10],
            ['sku' => 'MKN-0001', 'name' => 'Roti Tawar', 'category' => 'Makanan Ringan', 'purchase_price' => 12000, 'selling_price' => 15000, 'stock' => 20, 'minimum_stock' => 6],
            ['sku' => 'MKN-0002', 'name' => 'Mi Instan (karton 40)', 'category' => 'Makanan Ringan', 'purchase_price' => 120000, 'selling_price' => 135000, 'stock' => 15, 'minimum_stock' => 4],
            ['sku' => 'MKN-0003', 'name' => 'Krupuk Udang 200g', 'category' => 'Makanan Ringan', 'purchase_price' => 8500, 'selling_price' => 10000, 'stock' => 55, 'minimum_stock' => 12],
            ['sku' => 'BBU-0001', 'name' => 'Kecap Manis 275ml', 'category' => 'Bumbu & Rempah', 'purchase_price' => 12500, 'selling_price' => 14500, 'stock' => 6, 'minimum_stock' => 10],
            ['sku' => 'BBU-0002', 'name' => 'Garam 500g', 'category' => 'Bumbu & Rempah', 'purchase_price' => 4000, 'selling_price' => 5500, 'stock' => 70, 'minimum_stock' => 20],
            ['sku' => 'BBU-0003', 'name' => 'Penyedap Rasa 250g', 'category' => 'Bumbu & Rempah', 'purchase_price' => 9500, 'selling_price' => 11500, 'stock' => 40, 'minimum_stock' => 12],
            ['sku' => 'BBU-0004', 'name' => 'Sambal Botol 340ml', 'category' => 'Bumbu & Rempah', 'purchase_price' => 16000, 'selling_price' => 18500, 'stock' => 8, 'minimum_stock' => 8],
            ['sku' => 'RT-0001', 'name' => 'Sabun Cuci Piring 800ml', 'category' => 'Kebutuhan Rumah Tangga', 'purchase_price' => 14000, 'selling_price' => 16500, 'stock' => 30, 'minimum_stock' => 10],
            ['sku' => 'RT-0002', 'name' => 'Deterjen Bubuk 900g', 'category' => 'Kebutuhan Rumah Tangga', 'purchase_price' => 24000, 'selling_price' => 27000, 'stock' => 28, 'minimum_stock' => 8],
            ['sku' => 'RT-0003', 'name' => 'Pemutih Pakaian 900ml', 'category' => 'Kebutuhan Rumah Tangga', 'purchase_price' => 13000, 'selling_price' => 15500, 'stock' => 22, 'minimum_stock' => 6],
            ['sku' => 'RT-0004', 'name' => 'Pengharum Ruangan 400ml', 'category' => 'Kebutuhan Rumah Tangga', 'purchase_price' => 19000, 'selling_price' => 22000, 'stock' => 18, 'minimum_stock' => 5],
            ['sku' => 'PRW-0001', 'name' => 'Shampo Sachet 80ml', 'category' => 'Perawatan Diri', 'purchase_price' => 9000, 'selling_price' => 11000, 'stock' => 48, 'minimum_stock' => 12],
            ['sku' => 'PRW-0002', 'name' => 'Sabun Mandi 80g', 'category' => 'Perawatan Diri', 'purchase_price' => 3500, 'selling_price' => 5000, 'stock' => 90, 'minimum_stock' => 20],
            ['sku' => 'PRW-0003', 'name' => 'Pasta Gigi 190g', 'category' => 'Perawatan Diri', 'purchase_price' => 15000, 'selling_price' => 17500, 'stock' => 33, 'minimum_stock' => 10],
            ['sku' => 'PRW-0004', 'name' => 'Tisu Basah 50 lembar', 'category' => 'Perawatan Diri', 'purchase_price' => 11000, 'selling_price' => 13000, 'stock' => 26, 'minimum_stock' => 8],
        ];

        $categoryMap = Category::pluck('id', 'name');

        foreach ($products as $product) {
            Product::create([
                'category_id' => $categoryMap[$product['category']],
                'sku' => $product['sku'],
                'name' => $product['name'],
                'purchase_price' => $product['purchase_price'],
                'selling_price' => $product['selling_price'],
                'stock' => $product['stock'],
                'minimum_stock' => $product['minimum_stock'],
            ]);
        }
    }
}
