<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'Admin Demo',
            'email' => 'admin@arta.test',
            'password' => 'password123',
            'role' => 'admin',
        ]);

        User::create([
            'name' => 'Staff Demo',
            'email' => 'staff@arta.test',
            'password' => 'password123',
            'role' => 'staff',
        ]);

        User::factory()->count(3)->create();
    }
}
