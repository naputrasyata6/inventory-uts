<?php

namespace Database\Seeders;

use App\Models\Product;
use App\Models\Supplier;
use App\Models\User;
use App\Services\PurchaseService;
use App\Services\SaleService;
use Illuminate\Database\Seeder;

class TransactionSeeder extends Seeder
{
    public function run(): void
    {
        $purchaseService = app(PurchaseService::class);
        $saleService = app(SaleService::class);

        $users = User::pluck('id')->all();
        $supplierIds = Supplier::pluck('id')->all();

        // Pembelian historis: 30 hari terakhir.
        for ($i = 30; $i >= 1; $i--) {
            if ($i % 3 === 0) {
                continue;
            }

            $day = now()->subDays($i)->setTime(rand(8, 16), rand(0, 59));

            foreach (range(1, rand(1, 2)) as $ignored) {
                $productIds = Product::pluck('id')->all();
                shuffle($productIds);
                $productIds = array_slice($productIds, 0, rand(1, 4));

                $items = [];
                foreach ($productIds as $pid) {
                    $product = Product::find($pid);
                    $items[] = [
                        'product_id' => $pid,
                        'quantity' => rand(5, 40),
                        'unit_cost' => $product->purchase_price,
                    ];
                }

                $purchaseService->create([
                    'supplier_id' => $supplierIds[array_rand($supplierIds)],
                    'user_id' => $users[array_rand($users)],
                    'items' => $items,
                ], $day);
            }
        }

        // Penjualan historis: 14 hari terakhir.
        for ($i = 14; $i >= 0; $i--) {
            $day = now()->subDays($i)->setTime(rand(9, 18), rand(0, 59));

            foreach (range(1, rand(2, 5)) as $ignored) {
                $productIds = Product::where('stock', '>', 0)->pluck('id')->all();
                shuffle($productIds);
                $productIds = array_slice($productIds, 0, rand(1, 5));

                $items = [];
                foreach ($productIds as $pid) {
                    $product = Product::find($pid);
                    $qty = rand(1, min(8, $product->stock));
                    $items[] = ['product_id' => $pid, 'quantity' => $qty];
                }

                if (! $items) {
                    continue;
                }

                $saleService->create([
                    'user_id' => $users[array_rand($users)],
                    'items' => $items,
                ], $day);
            }
        }
    }
}
