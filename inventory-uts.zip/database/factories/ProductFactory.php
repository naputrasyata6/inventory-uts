<?php

namespace Database\Factories;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Product>
 */
class ProductFactory extends Factory
{
    public function definition(): array
    {
        return [
            'category_id' => Category::factory(),
            'sku' => fake()->unique()->bothify('SKU-####-??'),
            'name' => fake()->words(3, true),
            'purchase_price' => fake()->numberBetween(5000, 200000),
            'selling_price' => fn (array $attributes) => $attributes['purchase_price'] + fake()->numberBetween(1000, 15000),
            'stock' => fake()->numberBetween(0, 150),
            'minimum_stock' => fake()->numberBetween(0, 20),
        ];
    }
}
