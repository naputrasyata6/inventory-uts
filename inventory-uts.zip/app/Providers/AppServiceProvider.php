<?php

namespace App\Providers;

use App\Models\User;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\URL;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Jangan paksa https/root URL di lokal: aplikasi bisa diakses lewat
        // http://localhost:8000 maupun virtual host Laragon.
        if (app()->environment('production')) {
            URL::forceScheme('https');
        }
        Paginator::useBootstrapFive();

        Gate::define('manage-users', fn (User $user) => $user->isAdmin());
        Gate::define('delete-master-data', fn (User $user) => $user->isAdmin());
        Gate::define('cancel-transaction', fn (User $user) => $user->isAdmin());
    }
}
