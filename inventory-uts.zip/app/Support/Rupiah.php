<?php

namespace App\Support;

class Rupiah
{
    public static function format(int|float|string|null $amount): string
    {
        $amount = (float) ($amount ?? 0);

        return 'Rp '.number_format($amount, 0, ',', '.');
    }
}
