<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Sale;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class SaleService
{
    /**
     * Buat penjualan + item + kurangi stok dalam satu database transaction.
     * Harga diambil dari database, bukan dari input browser.
     */
    public function create(array $data, ?Carbon $at = null): Sale
    {
        $at ??= now();

        return DB::transaction(function () use ($data, $at) {
            $sale = Sale::create([
                'user_id' => $data['user_id'] ?? Auth::id(),
                'sale_number' => $this->nextNumber($at),
                'total' => 0,
                'status' => Sale::STATUS_COMPLETED,
                'sold_at' => $at,
            ]);

            $total = 0;
            $stockErrors = [];

            foreach ($data['items'] as $item) {
                $product = Product::whereKey($item['product_id'])->lockForUpdate()->firstOrFail();
                $qty = (int) $item['quantity'];

                if ($qty < 1) {
                    throw ValidationException::withMessages([
                        'items' => 'Kuantitas setiap barang harus lebih dari 0.',
                    ]);
                }

                if ($product->stock < $qty) {
                    $stockErrors[] = '"'.$product->name.'" stok tersedia '.$product->stock.' (diminta '.$qty.').';
                    continue;
                }

                $subtotal = $product->selling_price * $qty;

                $sale->items()->create([
                    'product_id' => $product->id,
                    'quantity' => $qty,
                    'unit_price' => $product->selling_price,
                    'subtotal' => $subtotal,
                ]);

                $product->decrement('stock', $qty);
                $total += $subtotal;
            }

            if ($stockErrors) {
                throw ValidationException::withMessages([
                    'items' => 'Stok tidak cukup untuk: '.implode(' ', $stockErrors),
                ]);
            }

            $sale->update(['total' => $total]);

            return $sale;
        });
    }

    /**
     * Batalkan penjualan: stok dikembalikan.
     */
    public function cancel(Sale $sale): void
    {
        if (! $sale->isCompleted()) {
            throw new \RuntimeException('Hanya transaksi yang sudah selesai yang dapat dibatalkan.');
        }

        DB::transaction(function () use ($sale) {
            $sale->update(['status' => Sale::STATUS_CANCELLED]);

            foreach ($sale->items as $item) {
                // Produk mungkin sudah di-soft-delete; stok tetap harus dikembalikan.
                Product::withTrashed()->whereKey($item->product_id)->increment('stock', $item->quantity);
            }
        });
    }

    private function nextNumber(Carbon $at): string
    {
        $date = $at->format('Ymd');
        $last = Sale::where('sale_number', 'like', "SL-{$date}-%")
            ->orderByDesc('sale_number')
            ->value('sale_number');

        $seq = $last ? ((int) substr($last, -4)) + 1 : 1;

        return sprintf('SL-%s-%04d', $date, $seq);
    }
}
