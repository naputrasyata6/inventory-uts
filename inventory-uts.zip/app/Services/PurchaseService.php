<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Purchase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PurchaseService
{
    /**
     * Buat pembelian + item + tambah stok dalam satu database transaction.
     */
    public function create(array $data, ?Carbon $at = null): Purchase
    {
        $at ??= now();

        return DB::transaction(function () use ($data, $at) {
            $purchase = Purchase::create([
                'supplier_id' => $data['supplier_id'],
                'user_id' => $data['user_id'] ?? Auth::id(),
                'purchase_number' => $this->nextNumber($at),
                'total' => 0,
                'status' => Purchase::STATUS_COMPLETED,
                'purchased_at' => $at,
            ]);

            $total = 0;

            foreach ($data['items'] as $item) {
                $product = Product::whereKey($item['product_id'])->lockForUpdate()->firstOrFail();
                $qty = (int) $item['quantity'];

                if ($qty < 1) {
                    throw ValidationException::withMessages([
                        'items' => 'Kuantitas setiap barang harus lebih dari 0.',
                    ]);
                }

                $subtotal = $qty * (float) $item['unit_cost'];

                $purchase->items()->create([
                    'product_id' => $product->id,
                    'quantity' => $qty,
                    'unit_cost' => $item['unit_cost'],
                    'subtotal' => $subtotal,
                ]);

                $product->increment('stock', $qty);
                $total += $subtotal;
            }

            $purchase->update(['total' => $total]);

            return $purchase;
        });
    }

    /**
     * Batalkan pembelian: stok dikembalikan hanya jika belum berpindah (terjual).
     */
    public function cancel(Purchase $purchase): void
    {
        if (! $purchase->isCompleted()) {
            throw new \RuntimeException('Hanya transaksi yang sudah selesai yang dapat dibatalkan.');
        }

        DB::transaction(function () use ($purchase) {
            foreach ($purchase->items as $item) {
                $product = Product::withTrashed()->whereKey($item->product_id)->lockForUpdate()->first();

                if ($product && $product->stock < $item->quantity) {
                    throw ValidationException::withMessages([
                        'status' => 'Tidak dapat membatalkan: stok "'.$product->name.'" sudah berpindah (terjual).',
                    ]);
                }
            }

            $purchase->update(['status' => Purchase::STATUS_CANCELLED]);

            foreach ($purchase->items as $item) {
                Product::withTrashed()->whereKey($item->product_id)->decrement('stock', $item->quantity);
            }
        });
    }

    private function nextNumber(Carbon $at): string
    {
        $date = $at->format('Ymd');
        $last = Purchase::where('purchase_number', 'like', "PRC-{$date}-%")
            ->orderByDesc('purchase_number')
            ->value('purchase_number');

        $seq = $last ? ((int) substr($last, -4)) + 1 : 1;

        return sprintf('PRC-%s-%04d', $date, $seq);
    }
}
