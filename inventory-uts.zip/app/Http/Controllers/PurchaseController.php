<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePurchaseRequest;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Supplier;
use App\Services\PurchaseService;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class PurchaseController extends Controller
{
    use AuthorizesRequests;

    public function __construct(private PurchaseService $purchaseService)
    {
    }

    public function index(Request $request)
    {
        $search = trim((string) $request->input('search'));
        $status = $request->input('status');
        $from = $request->input('from');
        $to = $request->input('to');

        $purchases = Purchase::query()
            ->with(['supplier', 'user'])
            ->withCount('items')
            ->when($search !== '', fn ($q) => $q->where(function ($q2) use ($search) {
                $q2->where('purchase_number', 'like', "%{$search}%")
                    ->orWhereHas('supplier', fn ($s) => $s->where('name', 'like', "%{$search}%"));
            }))
            ->when($status, fn ($q) => $q->where('status', $status))
            ->when($from, fn ($q) => $q->whereDate('purchased_at', '>=', $from))
            ->when($to, fn ($q) => $q->whereDate('purchased_at', '<=', $to))
            ->latest('purchased_at')
            ->paginate(12)
            ->withQueryString();

        return view('purchases.index', compact('purchases', 'search', 'status', 'from', 'to'));
    }

    public function create()
    {
        return view('purchases.create', [
            'suppliers' => Supplier::orderBy('name')->get(),
            'products' => Product::orderBy('name')->get(),
        ]);
    }

    public function store(StorePurchaseRequest $request)
    {
        $purchase = $this->purchaseService->create($request->validated());

        return redirect()->route('purchases.show', $purchase)->with('success', 'Pembelian berhasil disimpan dan stok bertambah.');
    }

    public function show(Purchase $purchase)
    {
        $purchase->load(['items.product', 'supplier', 'user']);

        return view('purchases.show', compact('purchase'));
    }

    public function cancel(Purchase $purchase)
    {
        $this->authorize('cancel-transaction');

        try {
            $this->purchaseService->cancel($purchase);
        } catch (\RuntimeException | ValidationException $e) {
            return back()->withErrors(['status' => $e->getMessage()]);
        }

        return back()->with('success', 'Pembelian dibatalkan dan stok dikembalikan.');
    }
}
