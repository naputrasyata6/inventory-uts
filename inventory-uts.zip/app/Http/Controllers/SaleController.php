<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreSaleRequest;
use App\Models\Product;
use App\Models\Sale;
use App\Services\SaleService;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class SaleController extends Controller
{
    use AuthorizesRequests;

    public function __construct(private SaleService $saleService)
    {
    }

    public function index(Request $request)
    {
        $search = trim((string) $request->input('search'));
        $status = $request->input('status');
        $from = $request->input('from');
        $to = $request->input('to');

        $sales = Sale::query()
            ->with('user')
            ->withCount('items')
            ->when($search !== '', fn ($q) => $q->where(function ($q2) use ($search) {
                $q2->where('sale_number', 'like', "%{$search}%")
                    ->orWhereHas('user', fn ($u) => $u->where('name', 'like', "%{$search}%"));
            }))
            ->when($status, fn ($q) => $q->where('status', $status))
            ->when($from, fn ($q) => $q->whereDate('sold_at', '>=', $from))
            ->when($to, fn ($q) => $q->whereDate('sold_at', '<=', $to))
            ->latest('sold_at')
            ->paginate(12)
            ->withQueryString();

        return view('sales.index', compact('sales', 'search', 'status', 'from', 'to'));
    }

    public function create()
    {
        return view('sales.create', [
            'products' => Product::orderBy('name')->get(),
        ]);
    }

    public function store(StoreSaleRequest $request)
    {
        $sale = $this->saleService->create($request->validated());

        return redirect()->route('sales.show', $sale)->with('success', 'Penjualan berhasil disimpan dan stok berkurang.');
    }

    public function show(Sale $sale)
    {
        $sale->load(['items.product', 'user']);

        return view('sales.show', compact('sale'));
    }

    public function cancel(Sale $sale)
    {
        $this->authorize('cancel-transaction');

        try {
            $this->saleService->cancel($sale);
        } catch (\RuntimeException | ValidationException $e) {
            return back()->withErrors(['status' => $e->getMessage()]);
        }

        return back()->with('success', 'Penjualan dibatalkan dan stok dikembalikan.');
    }
}
