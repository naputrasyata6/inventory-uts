<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\Supplier;

class DashboardController extends Controller
{
    public function index()
    {
        $todayStart = now()->startOfDay();
        $monthStart = now()->startOfMonth();

        $stats = [
            'products' => Product::count(),
            'suppliers' => Supplier::count(),
            'categories' => Category::count(),
            'low_stock' => Product::lowStock()->count(),
            'sales_today' => Sale::where('status', Sale::STATUS_COMPLETED)
                ->where('sold_at', '>=', $todayStart)->sum('total'),
            'sales_month' => Sale::where('status', Sale::STATUS_COMPLETED)
                ->where('sold_at', '>=', $monthStart)->sum('total'),
            'transactions' => Purchase::count() + Sale::count(),
        ];

        $lowStockProducts = Product::lowStock()->with('category')->orderBy('stock')->limit(5)->get();
        $recentSales = Sale::with('user')->latest('sold_at')->limit(5)->get();
        $recentPurchases = Purchase::with('supplier')->latest('purchased_at')->limit(5)->get();

        return view('dashboard.index', compact(
            'stats',
            'lowStockProducts',
            'recentSales',
            'recentPurchases'
        ));
    }
}
