(function () {
  "use strict";

  /* ---------- Theme toggle (light/dark) ---------- */
  var root = document.documentElement;
  var savedTheme = null;
  try { savedTheme = localStorage.getItem("arta-theme"); } catch (e) {}

  if (savedTheme === "dark") {
    root.setAttribute("data-bs-theme", "dark");
  }

  function syncThemeIcons() {
    var dark = root.getAttribute("data-bs-theme") === "dark";
    document.querySelectorAll("[data-arta-theme-toggle]").forEach(function (btn) {
      var sun = btn.querySelector(".icon-sun");
      var moon = btn.querySelector(".icon-moon");
      if (sun) sun.style.display = dark ? "" : "none";
      if (moon) moon.style.display = dark ? "none" : "";
    });
  }

  document.addEventListener("click", function (e) {
    var toggle = e.target.closest("[data-arta-theme-toggle]");
    if (!toggle) return;
    var next = root.getAttribute("data-bs-theme") === "dark" ? "light" : "dark";
    root.setAttribute("data-bs-theme", next);
    try { localStorage.setItem("arta-theme", next); } catch (err) {}
    syncThemeIcons();
  });

  syncThemeIcons();

  /* ---------- Mobile: close offcanvas after navigation ---------- */
  document.querySelectorAll('[data-bs-toggle="offcanvas"] + .offcanvas .nav-link').forEach(function (link) {
    link.addEventListener("click", function () {
      var offcanvas = link.closest(".offcanvas");
      if (offcanvas && bootstrap.Offcanvas.getInstance(offcanvas)) {
        bootstrap.Offcanvas.getInstance(offcanvas).hide();
      }
    });
  });

  /* ---------- Transaction rows (purchase & sale create) ---------- */
  var rowIndex = 0;

  window.artaTransactionRows = {
    init: function (containerId) {
      var container = document.getElementById(containerId);
      if (!container) return;

      var template = container.querySelector("template");
      var tbody = container.querySelector("tbody");
      var addBtn = container.querySelector("[data-add-row]");

      function rebuildIndexes() {
        tbody.querySelectorAll("tr[data-row]").forEach(function (tr, idx) {
          tr.querySelectorAll("[name]").forEach(function (input) {
            input.name = input.name.replace(/\[\d+\]/g, "[" + idx + "]");
          });
          tr.dataset.row = idx;
        });
        recalcTotals();
      }

      function createRow() {
        var frag = template.content.cloneNode(true);
        var tr = frag.querySelector("tr");
        tr.dataset.row = rowIndex;
        tr.querySelectorAll("[name]").forEach(function (input) {
          input.name = input.name.replace(/\[\d+\]/g, "[" + rowIndex + "]");
        });
        tbody.appendChild(frag);
        rowIndex++;
        bindRow(tr);
        recalcTotals();
        return tr;
      }

      function bindRow(tr) {
        tr.querySelectorAll("[data-product-select]").forEach(function (select) {
          select.addEventListener("change", function () {
            var opt = select.selectedOptions[0];
            var priceInput = tr.querySelector("[data-unit-price]") || tr.querySelector("[data-unit-cost]");
            var stockHint = tr.querySelector("[data-stock-hint]");
            if (opt) {
              if (priceInput) priceInput.value = opt.dataset.price || "";
              if (stockHint) {
                stockHint.textContent = "Stok tersedia: " + (opt.dataset.stock || "0");
                stockHint.classList.toggle("text-danger", parseInt(opt.dataset.stock || "0", 10) === 0);
              }
            }
            recalcRow(tr);
            recalcTotals();
          });
        });

        tr.querySelectorAll("[data-qty], [data-unit-cost]").forEach(function (input) {
          input.addEventListener("input", function () {
            recalcRow(tr);
            recalcTotals();
          });
        });

        var removeBtn = tr.querySelector("[data-remove-row]");
        if (removeBtn) {
          removeBtn.addEventListener("click", function () {
            tr.remove();
            rebuildIndexes();
          });
        }
      }

      function recalcRow(tr) {
        var productSelect = tr.querySelector("[data-product-select]");
        var qtyInput = tr.querySelector("[data-qty]");
        var costInput = tr.querySelector("[data-unit-cost]");
        var subtotalCell = tr.querySelector("[data-subtotal]");
        var qty = parseInt(qtyInput.value, 10) || 0;
        var unit = costInput ? (parseFloat(costInput.value) || 0) : (productSelect && productSelect.selectedOptions[0] ? parseFloat(productSelect.selectedOptions[0].dataset.price || "0") || 0 : 0);
        var subtotal = qty * unit;
        if (subtotalCell) subtotalCell.textContent = "Rp " + Number(subtotal).toLocaleString("id-ID");

        if (productSelect && qtyInput) {
          var opt = productSelect.selectedOptions[0];
          var stock = opt ? parseInt(opt.dataset.stock || "0", 10) : 0;
          var low = opt && qty > stock;
          qtyInput.classList.toggle("is-invalid", low);
          var feedback = tr.querySelector("[data-qty-feedback]");
          if (feedback) {
            feedback.textContent = low ? "Melebihi stok tersedia (" + stock + ")." : "";
          }
        }

        return subtotal;
      }

      function recalcTotals() {
        var grandTotal = 0;
        var anyInvalid = false;
        tbody.querySelectorAll("tr[data-row]").forEach(function (tr) {
          grandTotal += recalcRow(tr);
          if (tr.querySelector("[data-qty].is-invalid")) anyInvalid = true;
        });
        var totalEl = container.querySelector("[data-grand-total]");
        if (totalEl) totalEl.textContent = "Rp " + Number(grandTotal).toLocaleString("id-ID");
      }

      addBtn.addEventListener("click", createRow);

      // render existing rows (validation retry keeps old input)
      if (tbody.querySelectorAll("tr[data-row]").length === 0) {
        createRow();
      } else {
        tbody.querySelectorAll("tr[data-row]").forEach(function (tr) {
          bindRow(tr);
          tr.dataset.row = rowIndex++;
        });
        rebuildIndexes();
      }
    }
  };

  document.querySelectorAll("[data-transaction-form]").forEach(function (form) {
    window.artaTransactionRows.init(form.id);
  });
})();
