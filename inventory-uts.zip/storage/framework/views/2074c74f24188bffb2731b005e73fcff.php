<!doctype html>
<html lang="id" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masuk · ARTA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?php echo e(url('css/app.css')); ?>">
</head>
<body>
<div class="arta-auth">
    <div class="arta-auth-brand">
        <div>
            <div class="d-inline-flex align-items-center gap-2 fs-4 fw-bold text-white">
                <span class="brand-mark" style="width: 44px; height: 44px; border-radius: 12px; background: var(--arta-primary); color: #fff; display: grid; place-items: center;">
                    <i class="bi bi-box-seam-fill"></i>
                </span>
                ARTA<span style="color: var(--arta-primary)">.</span>
            </div>
            <p class="mt-4 mb-0 fw-light fs-6 lh-base" style="max-width: 420px; color: #c7d2e0;">
                Sistem inventori & penjualan untuk usaha distribusi kecil. Stok selalu konsisten dengan setiap transaksi.
            </p>
        </div>
        <div class="small" style="color:#8fa3bd;">Web Programming 2 — Integrated Laravel Project</div>
    </div>

    <div class="d-flex align-items-center justify-content-center p-4">
        <div class="auth-card">
            <div class="card shadow-none">
                <div class="card-body p-4 p-md-5">
                    <h2 class="h4 fw-bold mb-1">Selamat datang kembali</h2>
                    <p class="text-soft mb-4">Masuk untuk mengelola stok dan transaksi.</p>

                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input id="email" type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required autofocus>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Kata Sandi</label>
                            <input id="password" type="password" name="password" class="form-control" required>
                        </div>

                        <div class="form-check mb-4">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember">
                            <label class="form-check-label" for="remember">Ingat saya</label>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-2">
                            Masuk <i class="bi bi-arrow-right ms-1"></i>
                        </button>
                    </form>

                    <hr class="my-4">
                    <div class="rounded-3 p-3" style="background: var(--arta-surface-2);">
                        <div class="fw-semibold small mb-2">Akun demo</div>
                        <div class="small text-soft mb-1">Admin: <span class="font-monospace">admin@arta.test</span> / <span class="font-monospace">password123</span></div>
                        <div class="small text-soft">Staff: <span class="font-monospace">staff@arta.test</span> / <span class="font-monospace">password123</span></div>
                    </div>
                </div>
            </div>
            <p class="text-center text-soft small mt-4 mb-0">© <?php echo e(date('Y')); ?> ARTA Inventory · Data dummy untuk keperluan tugas</p>
        </div>
    </div>
</div>

<script src="<?php echo e(url('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/auth/login.blade.php ENDPATH**/ ?>