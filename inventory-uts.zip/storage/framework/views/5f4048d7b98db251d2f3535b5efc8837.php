<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="row g-2 g-lg-3 mb-3 mb-lg-4">
        <div class="col-6 col-xl-3">
            <div class="card stat-card h-100">
                <div class="card-body d-flex align-items-center gap-2 gap-lg-3">
                    <div class="stat-icon"><i class="bi bi-box-seam"></i></div>
                    <div>
                        <div class="text-soft small fw-semibold">Total Produk</div>
                        <div class="stat-value"><?php echo e(number_format($stats['products'])); ?></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="card stat-card h-100">
                <div class="card-body d-flex align-items-center gap-2 gap-lg-3">
                    <div class="stat-icon"><i class="bi bi-cash-coin"></i></div>
                    <div>
                        <div class="text-soft small fw-semibold">Penjualan Hari Ini</div>
                        <div class="stat-value fs-6"><?php echo e(App\Support\Rupiah::format($stats['sales_today'])); ?></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="card stat-card h-100">
                <div class="card-body d-flex align-items-center gap-2 gap-lg-3">
                    <div class="stat-icon"><i class="bi bi-graph-up-arrow"></i></div>
                    <div>
                        <div class="text-soft small fw-semibold">Penjualan Bulan Ini</div>
                        <div class="stat-value fs-6"><?php echo e(App\Support\Rupiah::format($stats['sales_month'])); ?></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="card stat-card h-100">
                <div class="card-body d-flex align-items-center gap-2 gap-lg-3">
                    <div class="stat-icon" style="background: var(--arta-accent-soft); color: var(--arta-accent);"><i class="bi bi-exclamation-diamond"></i></div>
                    <div>
                        <div class="text-soft small fw-semibold">Stok Rendah</div>
                        <div class="stat-value"><?php echo e(number_format($stats['low_stock'])); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row g-2 g-lg-3 d-none d-md-flex">
        <div class="col-lg-7">
            <div class="card h-100">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <span><i class="bi bi-exclamation-diamond me-2"></i>Produk Stok Rendah</span>
                    <a href="<?php echo e(route('low-stock.index')); ?>" class="btn btn-sm btn-soft-primary">Lihat semua</a>
                </div>
                <?php if($lowStockProducts->isEmpty()): ?>
                    <div class="empty-state">
                        <div class="empty-icon"><i class="bi bi-check2-circle"></i></div>
                        <div class="fw-semibold text-body">Tidak ada produk di bawah stok minimum</div>
                        <div class="small">Semua stok dalam kondisi sehat.</div>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead><tr><th>Produk</th><th>Kategori</th><th>Stok</th><th>Min.</th><th class="text-end">Aksi</th></tr></thead>
                            <tbody>
                                <?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('products.show', $product)); ?>" class="fw-semibold text-decoration-none"><?php echo e($product->name); ?></a>
                                            <div class="small text-soft"><?php echo e($product->sku); ?></div>
                                        </td>
                                        <td class="text-soft"><?php echo e($product->category?->name); ?></td>
                                        <td><span class="badge badge-status cancelled"><?php echo e($product->stock); ?></span></td>
                                        <td class="text-soft"><?php echo e($product->minimum_stock); ?></td>
                                        <td class="text-end"><a href="<?php echo e(route('purchases.create')); ?>" class="btn btn-sm btn-outline-primary">Beli stok</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card h-100">
                <div class="card-header"><i class="bi bi-clock-history me-2"></i>Transaksi Terbaru</div>
                <div class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $recentSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a class="list-group-item d-flex align-items-center gap-3 text-decoration-none" href="<?php echo e(route('sales.show', $sale)); ?>">
                            <span class="arta-thumb"><i class="bi bi-bag-check"></i></span>
                            <div class="flex-grow-1">
                                <div class="fw-semibold small"><?php echo e($sale->sale_number); ?></div>
                                <div class="small text-soft">Penjualan · <?php echo e($sale->sold_at->format('d M Y H:i')); ?></div>
                            </div>
                            <span class="fw-bold small"><?php echo e(App\Support\Rupiah::format($sale->total)); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $recentPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a class="list-group-item d-flex align-items-center gap-3 text-decoration-none" href="<?php echo e(route('purchases.show', $purchase)); ?>">
                            <span class="arta-thumb"><i class="bi bi-box-arrow-down"></i></span>
                            <div class="flex-grow-1">
                                <div class="fw-semibold small"><?php echo e($purchase->purchase_number); ?></div>
                                <div class="small text-soft">Pembelian · <?php echo e($purchase->purchased_at->format('d M Y H:i')); ?></div>
                            </div>
                            <span class="fw-bold small"><?php echo e(App\Support\Rupiah::format($purchase->total)); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="empty-state">
                            <div class="empty-icon"><i class="bi bi-receipt"></i></div>
                            <div class="fw-semibold text-body">Belum ada transaksi</div>
                            <div class="small">Mulai pencatatan dari menu Pembelian atau Penjualan.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <div class="d-md-none d-flex flex-column gap-2">
        
        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between py-2 px-3">
                <span class="small fw-semibold"><i class="bi bi-exclamation-diamond me-1"></i>Stok Rendah</span>
                <a href="<?php echo e(route('low-stock.index')); ?>" class="btn btn-sm btn-soft-primary py-1 px-2" style="font-size:.75rem">Lihat semua</a>
            </div>
            <?php if($lowStockProducts->isEmpty()): ?>
                <div class="card-body p-3 text-center">
                    <i class="bi bi-check2-circle text-success fs-4 d-block mb-1"></i>
                    <div class="small fw-semibold">Semua stok sehat</div>
                </div>
            <?php else: ?>
                <div class="list-group list-group-flush">
                    <?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item p-3">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="min-width-0">
                                    <a href="<?php echo e(route('products.show', $product)); ?>" class="fw-semibold text-decoration-none small text-truncate d-block"><?php echo e($product->name); ?></a>
                                    <div class="text-soft" style="font-size:.7rem"><?php echo e($product->sku); ?> · <?php echo e($product->category?->name); ?></div>
                                </div>
                                <div class="text-end flex-shrink-0 ms-2">
                                    <span class="badge badge-status cancelled"><?php echo e($product->stock); ?></span>
                                    <div class="text-soft" style="font-size:.65rem">min <?php echo e($product->minimum_stock); ?></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="card">
            <div class="card-header py-2 px-3">
                <span class="small fw-semibold"><i class="bi bi-clock-history me-1"></i>Transaksi Terbaru</span>
            </div>
            <div class="list-group list-group-flush">
                <?php $hasTransactions = false; ?>
                <?php $__empty_1 = true; $__currentLoopData = $recentSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $hasTransactions = true; ?>
                    <a class="list-group-item p-3 text-decoration-none" href="<?php echo e(route('sales.show', $sale)); ?>">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2 min-width-0">
                                <span class="arta-thumb" style="width:28px;height:28px;font-size:.7rem;border-radius:6px"><i class="bi bi-bag-check"></i></span>
                                <div class="min-width-0">
                                    <div class="fw-semibold small text-truncate"><?php echo e($sale->sale_number); ?></div>
                                    <div class="text-soft" style="font-size:.7rem"><?php echo e($sale->sold_at->format('d M H:i')); ?></div>
                                </div>
                            </div>
                            <span class="fw-bold small flex-shrink-0 ms-2"><?php echo e(App\Support\Rupiah::format($sale->total)); ?></span>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>
                <?php $__empty_1 = true; $__currentLoopData = $recentPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $hasTransactions = true; ?>
                    <a class="list-group-item p-3 text-decoration-none" href="<?php echo e(route('purchases.show', $purchase)); ?>">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2 min-width-0">
                                <span class="arta-thumb" style="width:28px;height:28px;font-size:.7rem;border-radius:6px"><i class="bi bi-box-arrow-down"></i></span>
                                <div class="min-width-0">
                                    <div class="fw-semibold small text-truncate"><?php echo e($purchase->purchase_number); ?></div>
                                    <div class="text-soft" style="font-size:.7rem"><?php echo e($purchase->purchased_at->format('d M H:i')); ?></div>
                                </div>
                            </div>
                            <span class="fw-bold small flex-shrink-0 ms-2"><?php echo e(App\Support\Rupiah::format($purchase->total)); ?></span>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>
                <?php if (! ($hasTransactions)): ?>
                    <div class="card-body p-3 text-center">
                        <i class="bi bi-receipt text-muted fs-4 d-block mb-1"></i>
                        <div class="small fw-semibold">Belum ada transaksi</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/dashboard/index.blade.php ENDPATH**/ ?>