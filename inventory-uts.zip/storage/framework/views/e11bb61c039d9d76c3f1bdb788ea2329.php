<?php $__env->startSection('title', 'Penjualan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Riwayat penjualan dan stok keluar.</p>
        <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Buat Penjualan
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body py-3">
            <form method="GET" action="<?php echo e(route('sales.index')); ?>" class="row g-2 align-items-end">
                <div class="col-12 col-md-4">
                    <label class="form-label small mb-1">Cari</label>
                    <input type="text" name="search" class="form-control" placeholder="Nomor atau kasir" value="<?php echo e($search); ?>">
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label small mb-1">Status</label>
                    <select name="status" class="form-select">
                        <option value="">Semua</option>
                        <option value="completed" <?php if($status === 'completed'): echo 'selected'; endif; ?>>Selesai</option>
                        <option value="cancelled" <?php if($status === 'cancelled'): echo 'selected'; endif; ?>>Dibatalkan</option>
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label small mb-1">Dari</label>
                    <input type="date" name="from" class="form-control" value="<?php echo e($from); ?>">
                </div>
                <div class="col-6 col-md-2">
                    <label class="form-label small mb-1">Sampai</label>
                    <input type="date" name="to" class="form-control" value="<?php echo e($to); ?>">
                </div>
                <div class="col-6 col-md-2 d-flex gap-2">
                    <button class="btn btn-primary flex-grow-1" type="submit"><i class="bi bi-search"></i></button>
                    <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-counterclockwise"></i></a>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr>
                    <th>Nomor</th><th>Kasir</th><th class="text-center">Item</th>
                    <th class="text-end">Total</th><th>Status</th><th>Tanggal</th><th class="text-end">Aksi</th>
                </tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="fw-semibold"><?php echo e($sale->sale_number); ?></td>
                            <td><?php echo e($sale->user?->name); ?></td>
                            <td class="text-center"><?php echo e($sale->items_count); ?></td>
                            <td class="text-end fw-semibold"><?php echo e(App\Support\Rupiah::format($sale->total)); ?></td>
                            <td><span class="badge badge-status <?php echo e($sale->status); ?>"><?php echo e($sale->isCompleted() ? 'Selesai' : 'Dibatalkan'); ?></span></td>
                            <td class="text-soft"><?php echo e($sale->sold_at->format('d M Y')); ?></td>
                            <td class="text-end"><a href="<?php echo e(route('sales.show', $sale)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye me-1"></i>Detail</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7"><div class="empty-state"><div class="empty-icon"><i class="bi bi-bag-check"></i></div><div class="fw-semibold">Belum ada penjualan</div><a href="<?php echo e(route('sales.create')); ?>" class="btn btn-sm btn-primary mt-3">Buat Penjualan</a></div></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($sales->hasPages()): ?><div class="card-footer"><?php echo e($sales->links()); ?></div><?php endif; ?>
    </div>

    
    <div class="d-md-none d-flex flex-column gap-2">
        <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('sales.show', $sale)); ?>" class="card text-decoration-none">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <span class="fw-semibold small"><?php echo e($sale->sale_number); ?></span>
                        <span class="badge badge-status <?php echo e($sale->status); ?>"><?php echo e($sale->isCompleted() ? 'Selesai' : 'Dibatalkan'); ?></span>
                    </div>
                    <div class="small text-soft mb-2"><?php echo e($sale->user?->name); ?> · <?php echo e($sale->sold_at->format('d M Y')); ?></div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="small"><?php echo e($sale->items_count); ?> item</span>
                        <span class="fw-bold"><?php echo e(App\Support\Rupiah::format($sale->total)); ?></span>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card"><div class="card-body"><div class="empty-state"><div class="empty-icon"><i class="bi bi-bag-check"></i></div><div class="fw-semibold">Belum ada penjualan</div><a href="<?php echo e(route('sales.create')); ?>" class="btn btn-sm btn-primary mt-3">Buat Penjualan</a></div></div></div>
        <?php endif; ?>
        <?php if($sales->hasPages()): ?><div class="card"><div class="card-footer"><?php echo e($sales->links()); ?></div></div><?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/sales/index.blade.php ENDPATH**/ ?>