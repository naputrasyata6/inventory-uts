<?php $__env->startSection('title', 'Produk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Kelola daftar produk, harga, dan stok.</p>
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Tambah Produk
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body py-3">
            <form method="GET" action="<?php echo e(route('products.index')); ?>" class="row g-2 align-items-end">
                <div class="col-12 col-md-5">
                    <label class="form-label small mb-1">Cari</label>
                    <input type="text" name="search" class="form-control" placeholder="SKU atau nama produk" value="<?php echo e($search); ?>">
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label small mb-1">Kategori</label>
                    <select name="category_id" class="form-select">
                        <option value="">Semua kategori</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php if((string) $categoryId === (string) $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-12 col-md-3 d-flex gap-2">
                    <button class="btn btn-primary flex-grow-1" type="submit"><i class="bi bi-search me-1"></i>Terapkan</button>
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-secondary" title="Reset filter"><i class="bi bi-arrow-counterclockwise"></i></a>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Kategori</th>
                        <th class="text-end">Harga Beli</th>
                        <th class="text-end">Harga Jual</th>
                        <th class="text-center">Stok</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <span class="arta-thumb"><?php echo e(strtoupper(substr($product->name, 0, 1))); ?></span>
                                    <div>
                                        <a href="<?php echo e(route('products.show', $product)); ?>" class="fw-semibold text-decoration-none"><?php echo e($product->name); ?></a>
                                        <div class="small text-soft"><?php echo e($product->sku); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-soft"><?php echo e($product->category?->name); ?></td>
                            <td class="text-end"><?php echo e(App\Support\Rupiah::format($product->purchase_price)); ?></td>
                            <td class="text-end fw-semibold"><?php echo e(App\Support\Rupiah::format($product->selling_price)); ?></td>
                            <td class="text-center">
                                <span class="badge badge-status <?php echo e($product->is_low_stock ? 'cancelled' : 'completed'); ?>">
                                    <?php echo e($product->stock); ?>

                                </span>
                                <span class="d-block small text-soft mt-1">min <?php echo e($product->minimum_stock); ?></span>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('products.show', $product)); ?>" class="btn btn-outline-secondary" title="Detail"><i class="bi bi-eye"></i></a>
                                    <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-outline-secondary" title="Ubah"><i class="bi bi-pencil"></i></a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-master-data')): ?>
                                        <form method="POST" action="<?php echo e(route('products.destroy', $product)); ?>" onsubmit="return confirm('Hapus produk ini?')" class="d-inline">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline-danger" title="Hapus"><i class="bi bi-trash"></i></button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6">
                            <div class="empty-state">
                                <div class="empty-icon"><i class="bi bi-box-seam"></i></div>
                                <div class="fw-semibold text-body">Belum ada produk</div>
                                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-sm btn-primary mt-3">Tambah Produk</a>
                            </div>
                        </td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($products->hasPages()): ?>
            <div class="card-footer"><?php echo e($products->links()); ?></div>
        <?php endif; ?>
    </div>

    
    <div class="d-md-none d-flex flex-column gap-2">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card">
                <div class="card-body p-3">
                    <div class="d-flex align-items-start gap-3">
                        <span class="arta-thumb flex-shrink-0"><?php echo e(strtoupper(substr($product->name, 0, 1))); ?></span>
                        <div class="flex-grow-1 min-width-0">
                            <a href="<?php echo e(route('products.show', $product)); ?>" class="fw-semibold text-decoration-none text-truncate d-block"><?php echo e($product->name); ?></a>
                            <div class="small text-soft"><?php echo e($product->sku); ?> · <?php echo e($product->category?->name); ?></div>
                        </div>
                        <span class="badge badge-status <?php echo e($product->is_low_stock ? 'cancelled' : 'completed'); ?> flex-shrink-0">
                            Stok <?php echo e($product->stock); ?>

                        </span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-2 pt-2 border-top">
                        <div class="small">
                            <span class="text-soft">Beli:</span> <?php echo e(App\Support\Rupiah::format($product->purchase_price)); ?>

                            <span class="text-soft ms-2">Jual:</span> <strong><?php echo e(App\Support\Rupiah::format($product->selling_price)); ?></strong>
                        </div>
                        <div class="btn-group btn-group-sm">
                            <a href="<?php echo e(route('products.show', $product)); ?>" class="btn btn-outline-secondary"><i class="bi bi-eye"></i></a>
                            <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-outline-secondary"><i class="bi bi-pencil"></i></a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-master-data')): ?>
                                <form method="POST" action="<?php echo e(route('products.destroy', $product)); ?>" onsubmit="return confirm('Hapus?')" class="d-inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card">
                <div class="card-body">
                    <div class="empty-state">
                        <div class="empty-icon"><i class="bi bi-box-seam"></i></div>
                        <div class="fw-semibold text-body">Belum ada produk</div>
                        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-sm btn-primary mt-3">Tambah Produk</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($products->hasPages()): ?>
            <div class="card"><div class="card-footer"><?php echo e($products->links()); ?></div></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/products/index.blade.php ENDPATH**/ ?>