<tr data-row>
    <td style="min-width: 220px;">
        <select class="form-select form-select-sm <?php $__errorArgs = ['items.'.$index.'.product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="items[<?php echo e($index); ?>][product_id]" data-product-select required>
            <option value="">Pilih produk</option>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($product->id); ?>"
                    data-price="<?php echo e($product->purchase_price); ?>"
                    <?php if(
                        ((isset($item['product_id']) && (string) $item['product_id'] === (string) $product->id) ||
                        (string) old('items.'.$index.'.product_id') === (string) $product->id)
                    ): echo 'selected'; endif; ?>
                ><?php echo e($product->name); ?> (<?php echo e($product->sku); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['items.'.$index.'.product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
    <td style="width: 120px;">
        <input type="number" min="1" name="items[<?php echo e($index); ?>][quantity]" data-qty class="form-control form-control-sm <?php $__errorArgs = ['items.'.$index.'.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($item['quantity'] ?? old('items.'.$index.'.quantity')); ?>" required>
        <?php $__errorArgs = ['items.'.$index.'.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
    <td style="width: 190px;">
        <div class="input-group input-group-sm">
            <span class="input-group-text">Rp</span>
            <input type="number" min="0" step="0.01" name="items[<?php echo e($index); ?>][unit_cost]" data-unit-cost class="form-control <?php $__errorArgs = ['items.'.$index.'.unit_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($item['unit_cost'] ?? old('items.'.$index.'.unit_cost')); ?>" required>
            <?php $__errorArgs = ['items.'.$index.'.unit_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </td>
    <td class="text-end fw-semibold text-nowrap" data-subtotal>Rp 0</td>
    <td class="text-end" style="width: 60px;">
        <button type="button" class="btn btn-sm btn-outline-danger" data-remove-row title="Hapus baris" aria-label="Hapus baris">
            <i class="bi bi-trash"></i>
        </button>
    </td>
</tr>
<?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/purchases/_row.blade.php ENDPATH**/ ?>