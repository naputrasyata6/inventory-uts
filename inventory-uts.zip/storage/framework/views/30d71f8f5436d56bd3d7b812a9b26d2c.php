<?php $__env->startSection('title', 'Detail Produk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row g-4">
        <div class="col-lg-7">
            <div class="card h-100">
                <div class="card-body p-4">
                    <div class="d-flex align-items-start gap-3 mb-4">
                        <span class="arta-thumb" style="width: 56px; height: 56px; font-size: 1.25rem;"><?php echo e(strtoupper(substr($product->name, 0, 1))); ?></span>
                        <div class="flex-grow-1">
                            <h2 class="h4 fw-bold mb-1"><?php echo e($product->name); ?></h2>
                            <div class="text-soft"><?php echo e($product->sku); ?> · <?php echo e($product->category?->name); ?></div>
                        </div>
                        <div class="d-flex gap-2">
                            <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil me-1"></i>Ubah</a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-master-data')): ?>
                                <form method="POST" action="<?php echo e(route('products.destroy', $product)); ?>" onsubmit="return confirm('Hapus produk ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-sm-6">
                            <div class="rounded-3 p-3" style="background: var(--arta-surface-2);">
                                <div class="text-soft small">Harga Beli</div>
                                <div class="fw-bold fs-5"><?php echo e(App\Support\Rupiah::format($product->purchase_price)); ?></div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="rounded-3 p-3" style="background: var(--arta-surface-2);">
                                <div class="text-soft small">Harga Jual</div>
                                <div class="fw-bold fs-5"><?php echo e(App\Support\Rupiah::format($product->selling_price)); ?></div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="rounded-3 p-3" style="background: var(--arta-surface-2);">
                                <div class="text-soft small">Stok Saat Ini</div>
                                <div class="d-flex align-items-center gap-2 mt-1">
                                    <span class="fw-bold fs-5"><?php echo e($product->stock); ?></span>
                                    <?php if($product->is_low_stock): ?>
                                        <span class="badge badge-status cancelled">Stok rendah</span>
                                    <?php else: ?>
                                        <span class="badge badge-status completed">Aman</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="rounded-3 p-3" style="background: var(--arta-surface-2);">
                                <div class="text-soft small">Stok Minimum</div>
                                <div class="fw-bold fs-5"><?php echo e($product->minimum_stock); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card h-100">
                <div class="card-header">Ringkasan Transaksi</div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between px-0">
                            <span class="text-soft">Total Pembelian</span>
                            <span class="fw-semibold"><?php echo e($product->purchaseItems()->count()); ?> transaksi</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between px-0">
                            <span class="text-soft">Total Penjualan</span>
                            <span class="fw-semibold"><?php echo e($product->saleItems()->count()); ?> transaksi</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between px-0">
                            <span class="text-soft">Margin per unit</span>
                            <span class="fw-semibold"><?php echo e(App\Support\Rupiah::format($product->selling_price - $product->purchase_price)); ?></span>
                        </li>
                    </ul>
                    <a href="<?php echo e(route('purchases.create')); ?>" class="btn btn-soft-primary w-100 mt-3">
                        <i class="bi bi-plus-lg me-1"></i>Beli stok produk ini
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/products/show.blade.php ENDPATH**/ ?>