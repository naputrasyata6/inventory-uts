<?php $__env->startSection('title', 'Detail Pembelian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-start justify-content-between flex-wrap gap-2 mb-4">
                        <div>
                            <div class="d-flex align-items-center gap-2 mb-1">
                                <span class="badge badge-status <?php echo e($purchase->status); ?>"><?php echo e($purchase->isCompleted() ? 'Selesai' : 'Dibatalkan'); ?></span>
                                <span class="fw-bold fs-5"><?php echo e($purchase->purchase_number); ?></span>
                            </div>
                            <div class="text-soft"><?php echo e($purchase->purchased_at->format('d F Y, H:i')); ?></div>
                        </div>
                        <a href="<?php echo e(route('purchases.index')); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Kembali</a>
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-sm-6">
                            <div class="rounded-3 p-3" style="background: var(--arta-surface-2);">
                                <div class="text-soft small">Pemasok</div>
                                <div class="fw-semibold"><?php echo e($purchase->supplier?->name); ?></div>
                                <div class="small text-soft"><?php echo e($purchase->supplier?->phone); ?></div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="rounded-3 p-3" style="background: var(--arta-surface-2);">
                                <div class="text-soft small">Dicatat oleh</div>
                                <div class="fw-semibold"><?php echo e($purchase->user?->name); ?></div>
                                <div class="small text-soft"><?php echo e($purchase->user?->isAdmin() ? 'Administrator' : 'Staff'); ?></div>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Produk</th>
                                    <th class="text-center" style="width: 90px;">Jumlah</th>
                                    <th class="text-end" style="width: 150px;">Harga/unit</th>
                                    <th class="text-end" style="width: 160px;">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="fw-semibold"><?php echo e($item->product?->name ?? 'Produk terhapus'); ?></div>
                                            <div class="small text-soft"><?php echo e($item->product?->sku); ?></div>
                                        </td>
                                        <td class="text-center"><?php echo e($item->quantity); ?></td>
                                        <td class="text-end"><?php echo e(App\Support\Rupiah::format($item->unit_cost)); ?></td>
                                        <td class="text-end fw-semibold"><?php echo e(App\Support\Rupiah::format($item->subtotal)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" class="text-end fw-semibold text-soft">Total</td>
                                    <td class="text-end fs-5 fw-bold"><?php echo e(App\Support\Rupiah::format($purchase->total)); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">Tindakan</div>
                <div class="card-body">
                    <p class="small text-soft">
                        Pembatalan hanya dapat dilakukan jika stok barang belum berpindah (terjual kembali).
                        Saat dibatalkan, stok dikembalikan ke kondisi sebelum pembelian.
                    </p>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cancel-transaction')): ?>
                        <?php if($purchase->isCompleted()): ?>
                            <form method="POST" action="<?php echo e(route('purchases.cancel', $purchase)); ?>" onsubmit="return confirm('Yakin membatalkan pembelian ini? Stok akan dikembalikan.')">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-danger w-100">
                                    <i class="bi bi-x-circle me-1"></i>Batalkan Pembelian
                                </button>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-light border mb-0">
                                <i class="bi bi-info-circle me-2"></i>Transaksi ini sudah dibatalkan.
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('cancel-transaction')): ?>
                        <div class="alert alert-light border mb-0">
                            <i class="bi bi-shield-lock me-2"></i>Hanya administrator yang dapat membatalkan transaksi.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/purchases/show.blade.php ENDPATH**/ ?>