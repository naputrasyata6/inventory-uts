
<nav class="flex-grow-1 pb-2 overflow-auto">
    <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
        <i class="bi bi-grid-1x2-fill"></i> Dashboard
    </a>

    <div class="nav-section">Data Master</div>
    <a class="nav-link <?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>" href="<?php echo e(route('products.index')); ?>">
        <i class="bi bi-box-seam"></i> Produk
    </a>
    <a class="nav-link <?php echo e(request()->routeIs('categories.*') ? 'active' : ''); ?>" href="<?php echo e(route('categories.index')); ?>">
        <i class="bi bi-tags"></i> Kategori
    </a>
    <a class="nav-link <?php echo e(request()->routeIs('suppliers.*') ? 'active' : ''); ?>" href="<?php echo e(route('suppliers.index')); ?>">
        <i class="bi bi-truck"></i> Pemasok
    </a>

    <div class="nav-section">Transaksi</div>
    <a class="nav-link <?php echo e(request()->routeIs('purchases.*') ? 'active' : ''); ?>" href="<?php echo e(route('purchases.index')); ?>">
        <i class="bi bi-box-arrow-down"></i> Pembelian
    </a>
    <a class="nav-link <?php echo e(request()->routeIs('sales.*') ? 'active' : ''); ?>" href="<?php echo e(route('sales.index')); ?>">
        <i class="bi bi-bag-check"></i> Penjualan
    </a>

    <div class="nav-section">Inventori</div>
    <a class="nav-link <?php echo e(request()->routeIs('low-stock.index') ? 'active' : ''); ?>" href="<?php echo e(route('low-stock.index')); ?>">
        <i class="bi bi-exclamation-diamond"></i> Stok Rendah
    </a>

    <?php if(Auth::user()->isAdmin()): ?>
        <div class="nav-section">Manajemen</div>
        <a class="nav-link <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>">
            <i class="bi bi-people"></i> Pengguna
        </a>
    <?php endif; ?>
</nav>
<?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/layouts/partials/nav.blade.php ENDPATH**/ ?>