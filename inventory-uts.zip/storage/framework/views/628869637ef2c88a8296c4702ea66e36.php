<?php $__env->startSection('title', 'Kategori'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Kelompokkan produk agar lebih mudah dicari.</p>
        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Tambah Kategori
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body py-3">
            <form method="GET" action="<?php echo e(route('categories.index')); ?>" class="row g-2 align-items-end">
                <div class="col-12 col-md-8">
                    <label class="form-label small mb-1">Cari</label>
                    <input type="text" name="search" class="form-control" placeholder="Nama kategori" value="<?php echo e($search); ?>">
                </div>
                <div class="col-12 col-md-4 d-flex gap-2">
                    <button class="btn btn-primary flex-grow-1" type="submit"><i class="bi bi-search me-1"></i>Terapkan</button>
                    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-counterclockwise"></i></a>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr><th>Nama</th><th>Deskripsi</th><th class="text-center">Jumlah Produk</th><th class="text-end">Aksi</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="fw-semibold"><?php echo e($category->name); ?></td>
                            <td class="text-soft small"><?php echo e(Str::limit($category->description, 50)); ?></td>
                            <td class="text-center"><?php echo e($category->products_count); ?></td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('categories.edit', $category)); ?>" class="btn btn-outline-secondary"><i class="bi bi-pencil"></i></a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-master-data')): ?>
                                        <form method="POST" action="<?php echo e(route('categories.destroy', $category)); ?>" onsubmit="return confirm('Hapus kategori ini?')" class="d-inline">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4"><div class="empty-state"><div class="empty-icon"><i class="bi bi-tags"></i></div><div class="fw-semibold">Belum ada kategori</div><a href="<?php echo e(route('categories.create')); ?>" class="btn btn-sm btn-primary mt-3">Tambah Kategori</a></div></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($categories->hasPages()): ?><div class="card-footer"><?php echo e($categories->links()); ?></div><?php endif; ?>
    </div>

    
    <div class="d-md-none d-flex flex-column gap-2">
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <span class="fw-semibold"><?php echo e($category->name); ?></span>
                        <span class="badge bg-light text-dark border"><?php echo e($category->products_count); ?> produk</span>
                    </div>
                    <?php if($category->description): ?>
                        <div class="small text-soft mb-2"><?php echo e(Str::limit($category->description, 60)); ?></div>
                    <?php endif; ?>
                    <div class="d-flex gap-2 pt-2 border-top">
                        <a href="<?php echo e(route('categories.edit', $category)); ?>" class="btn btn-sm btn-outline-secondary flex-grow-1"><i class="bi bi-pencil me-1"></i>Ubah</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-master-data')): ?>
                            <form method="POST" action="<?php echo e(route('categories.destroy', $category)); ?>" onsubmit="return confirm('Hapus?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card"><div class="card-body"><div class="empty-state"><div class="empty-icon"><i class="bi bi-tags"></i></div><div class="fw-semibold">Belum ada kategori</div><a href="<?php echo e(route('categories.create')); ?>" class="btn btn-sm btn-primary mt-3">Tambah Kategori</a></div></div></div>
        <?php endif; ?>
        <?php if($categories->hasPages()): ?><div class="card"><div class="card-footer"><?php echo e($categories->links()); ?></div></div><?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/categories/index.blade.php ENDPATH**/ ?>