<?php $__env->startSection('title', 'Stok Rendah'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Produk dengan stok pada atau di bawah batas minimum.</p>
        <a href="<?php echo e(route('purchases.create')); ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>Buat Pembelian
        </a>
    </div>

    
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr><th>Produk</th><th>Kategori</th><th class="text-center">Stok</th><th class="text-center">Minimum</th><th class="text-center">Selisih</th><th class="text-end">Aksi</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="arta-thumb"><?php echo e(strtoupper(substr($product->name, 0, 1))); ?></span>
                                    <div>
                                        <a href="<?php echo e(route('products.show', $product)); ?>" class="fw-semibold text-decoration-none"><?php echo e($product->name); ?></a>
                                        <div class="small text-soft"><?php echo e($product->sku); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-soft"><?php echo e($product->category?->name); ?></td>
                            <td class="text-center"><span class="badge badge-status cancelled"><?php echo e($product->stock); ?></span></td>
                            <td class="text-center text-soft"><?php echo e($product->minimum_stock); ?></td>
                            <td class="text-center text-danger fw-semibold"><?php echo e($product->stock - $product->minimum_stock); ?></td>
                            <td class="text-end"><a href="<?php echo e(route('purchases.create')); ?>" class="btn btn-sm btn-outline-primary">Beli stok</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6"><div class="empty-state"><div class="empty-icon"><i class="bi bi-check2-circle"></i></div><div class="fw-semibold">Semua stok sehat</div></div></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="d-md-none d-flex flex-column gap-2">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card border-danger-subtle">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <div class="d-flex align-items-center gap-2">
                            <span class="arta-thumb"><?php echo e(strtoupper(substr($product->name, 0, 1))); ?></span>
                            <div>
                                <a href="<?php echo e(route('products.show', $product)); ?>" class="fw-semibold text-decoration-none"><?php echo e($product->name); ?></a>
                                <div class="small text-soft"><?php echo e($product->sku); ?> · <?php echo e($product->category?->name); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-2 pt-2 border-top">
                        <div class="small">
                            <span class="text-danger fw-bold">Stok: <?php echo e($product->stock); ?></span>
                            <span class="text-soft ms-1">/ min <?php echo e($product->minimum_stock); ?></span>
                            <span class="text-danger ms-1">(selisih <?php echo e($product->stock - $product->minimum_stock); ?>)</span>
                        </div>
                        <a href="<?php echo e(route('purchases.create')); ?>" class="btn btn-sm btn-outline-primary">Beli</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card"><div class="card-body"><div class="empty-state"><div class="empty-icon"><i class="bi bi-check2-circle"></i></div><div class="fw-semibold">Semua stok sehat</div></div></div></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/products/low-stock.blade.php ENDPATH**/ ?>