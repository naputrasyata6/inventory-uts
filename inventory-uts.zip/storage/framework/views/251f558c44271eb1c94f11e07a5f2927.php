<?php $__env->startSection('title', 'Pengguna'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <p class="text-soft mb-0 small">Kelola akun dan hak akses pengguna.</p>
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-person-plus me-1"></i>Tambah Pengguna
        </a>
    </div>

    <div class="card mb-3">
        <div class="card-body py-3">
            <form method="GET" action="<?php echo e(route('users.index')); ?>" class="row g-2 align-items-end">
                <div class="col-12 col-md-8">
                    <label class="form-label small mb-1">Cari</label>
                    <input type="text" name="search" class="form-control" placeholder="Nama atau email" value="<?php echo e($search); ?>">
                </div>
                <div class="col-12 col-md-4 d-flex gap-2">
                    <button class="btn btn-primary flex-grow-1" type="submit"><i class="bi bi-search me-1"></i>Terapkan</button>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-counterclockwise"></i></a>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr><th>Nama</th><th>Email</th><th>Role</th><th>Terdaftar</th><th class="text-end">Aksi</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="arta-thumb"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></span>
                                    <span class="fw-semibold"><?php echo e($user->name); ?></span>
                                    <?php if($user->id === auth()->id()): ?><span class="badge bg-primary-subtle text-primary small">Anda</span><?php endif; ?>
                                </div>
                            </td>
                            <td class="text-soft"><?php echo e($user->email); ?></td>
                            <td><span class="badge <?php echo e($user->isAdmin() ? 'bg-primary' : 'bg-secondary'); ?>"><?php echo e($user->isAdmin() ? 'Administrator' : 'Staff'); ?></span></td>
                            <td class="text-soft small"><?php echo e($user->created_at->format('d M Y')); ?></td>
                            <td class="text-end">
                                <?php if($user->id !== auth()->id()): ?>
                                    <div class="btn-group btn-group-sm">
                                        <form method="POST" action="<?php echo e(route('users.toggle-role', $user)); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-outline-secondary" title="<?php echo e($user->isAdmin() ? 'Jadikan Staff' : 'Jadikan Admin'); ?>">
                                                <i class="bi bi-person-gear"></i>
                                            </button>
                                        </form>
                                        <form method="POST" action="<?php echo e(route('users.destroy', $user)); ?>" onsubmit="return confirm('Hapus pengguna ini?')" class="d-inline">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5"><div class="empty-state"><div class="empty-icon"><i class="bi bi-people"></i></div><div class="fw-semibold">Belum ada pengguna</div></div></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($users->hasPages()): ?><div class="card-footer"><?php echo e($users->links()); ?></div><?php endif; ?>
    </div>

    
    <div class="d-md-none d-flex flex-column gap-2">
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <div class="d-flex align-items-center gap-2">
                            <span class="arta-thumb"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></span>
                            <div>
                                <span class="fw-semibold"><?php echo e($user->name); ?></span>
                                <?php if($user->id === auth()->id()): ?><span class="badge bg-primary-subtle text-primary small ms-1">Anda</span><?php endif; ?>
                            </div>
                        </div>
                        <span class="badge <?php echo e($user->isAdmin() ? 'bg-primary' : 'bg-secondary'); ?>"><?php echo e($user->isAdmin() ? 'Admin' : 'Staff'); ?></span>
                    </div>
                    <div class="small text-soft mb-2"><?php echo e($user->email); ?> · <?php echo e($user->created_at->format('d M Y')); ?></div>
                    <?php if($user->id !== auth()->id()): ?>
                        <div class="d-flex gap-2 pt-2 border-top">
                            <form method="POST" action="<?php echo e(route('users.toggle-role', $user)); ?>" class="flex-grow-1">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-outline-secondary w-100">
                                    <i class="bi bi-person-gear me-1"></i><?php echo e($user->isAdmin() ? 'Jadikan Staff' : 'Jadikan Admin'); ?>

                                </button>
                            </form>
                            <form method="POST" action="<?php echo e(route('users.destroy', $user)); ?>" onsubmit="return confirm('Hapus?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card"><div class="card-body"><div class="empty-state"><div class="empty-icon"><i class="bi bi-people"></i></div><div class="fw-semibold">Belum ada pengguna</div></div></div></div>
        <?php endif; ?>
        <?php if($users->hasPages()): ?><div class="card"><div class="card-footer"><?php echo e($users->links()); ?></div></div><?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\arta-inventory-uts\resources\views/users/index.blade.php ENDPATH**/ ?>